<?php
if (!defined('N3N')) {
    header("HTTP/1.0: 404 Not Found");
    $notfound =
        "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">" .
        "<HTML>" .
        "<HEAD>" .
        "<TITLE>404 Not Found</TITLE>" .
        "</HEAD>" .
        "<BODY>" .
        "<H1>Not Found</H1>" .
        "The requested URL " . htmlspecialchars($_SERVER['REQUEST_URI']) . " was not found on this server." .
        "</BODY>" .
        "</HTML>";
    die($notfound);
}
define('SID', session_id());

function login($username, $password)
{
    $result = mysql_query("SELECT * FROM `users` WHERE `username`='$username' AND `password`='$password';")
    or die(mysql_error());
    $USER = mysql_fetch_array($result, 1);
    if (!empty($USER)) {
        $_SESSION = array_merge($_SESSION, $USER);

        mysql_query("UPDATE users SET `sid`='" . SID . "' WHERE `uid`='" . $USER['uid'] . "';")
        or die(mysql_error());
        return true;
    } else {
        return false;
    }
}

function check_user($uid)
{
    $result = mysql_query("SELECT `sid` FROM `users` WHERE `uid`='$uid';") or die(mysql_error());
    $sid = mysql_result($result, 0);
    return $sid == SID ? true : false;
}

function change_passw($password)
{
    $username = $_SESSION['username'];
    if (strlen($username) > 0 & strlen($password) > 0)
        mysql_query("update users set password='$password' where username = '$username'") or die(mysql_error());

   MessageRedirect("?act=settings");
}

function register_new($username, $password)
{
    global $account_list;
    if (strlen($username) > 0 & strlen($password) > 0 & $username != "admin")
        $result = mysql_query("REPLACE INTO users (`uid`, `username`, `password`, `type`, `sid`) VALUES ('" . $username . "', '" . $username . "', '" . $password . "', 'user', '');") or die(mysql_error());
    MessageRedirect($account_list);
}


if (isset($_SESSION['uid'])) {

    define('USER_LOGGED', true);

    $UserName = $_SESSION['username'];
    $UserPass = $_SESSION['password'];
    $UserType = $_SESSION['type'];
    $UserID = $_SESSION['uid'];
} else {
    define('USER_LOGGED', false);
}

if (isset($_POST['login'])) {
    if (get_magic_quotes_gpc()) {
        $_POST['user'] = stripslashes($_POST['user']);
        $_POST['pass'] = stripslashes($_POST['pass']);
    }

    $user = mysql_real_escape_string($_POST['user']);
    $pass = mysql_real_escape_string($_POST['pass']);
    if (login($user, $pass)) {
        header('Refresh: 0');
    }
}