<?php
define('N3N', 1);
include("../config.php");
include("../functions.php");
$real_ip = null;

if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) // CloudFlare Visitor IPs fix
{
    $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
}

if (!isset($_POST['ip'])) {
    $real_ip = $_SERVER['REMOTE_ADDR'];
} else {
    $real_ip = $_POST['ip'];
}

ConnectMySQL($db_host, $db_login, $db_password, $db_database);
CheckBan($real_ip);
AddBan($real_ip);