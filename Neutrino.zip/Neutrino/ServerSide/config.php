<?php
error_reporting(0);
//error_reporting(E_ALL);

if(!defined('N3N'))
{
    header("HTTP/1.0: 404 Not Found");
    $notfound =
        "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">" .
            "<HTML>" .
            "<HEAD>" .
            "<TITLE>404 Not Found</TITLE>" .
            "</HEAD>" .
            "<BODY>" .
            "<H1>Not Found</H1>" .
            "The requested URL " . htmlspecialchars($_SERVER['REQUEST_URI']) . " was not found on this server." .
            "</BODY>" .
        "</HTML>";
    die($notfound);
}

include("GeoIP/geoip.php");
include("inc/countries.php");
include("inc/code2name.php");

$key_start = "DEBUG";
$key_end = "DEBUG";
$tasks_url = "?act=tasks";
$stats_url = "?act=stats";
$bots_url = "?act=clients";
$bots_files = "?act=files";
$logs_files = "?act=logs";
$ff = "?act=ff";
$dumps = "?act=dumps";
$black_list = "?act=settings&do=blacklist";
$account_list = "?act=settings&do=accountlist";
$upload_files = "?act=upload";
$set_rate = "rate";

$adelim = "#";
global $tasks_url, $stats_url, $bots_url, $logs_files, $bots_files, $adelim, $act, $country_codes, $country_names;

