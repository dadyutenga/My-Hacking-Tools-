CREATE TABLE IF NOT EXISTS `bots` (
  `id` varchar(255) NOT NULL,
  `last_ip` varchar(15) NOT NULL,
  `last_online` int(10) NOT NULL,
  `new` tinyint(1) NOT NULL,
  `version` varchar(6) NOT NULL,
  `OS` varchar(10) NOT NULL,
  `User` varchar(255) NOT NULL,
  `command` varchar(255) NOT NULL,
  `regdate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
