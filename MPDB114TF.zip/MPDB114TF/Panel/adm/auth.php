<?php

define("FILE", true);
include("../inc/config.php");
include("../inc/lang.php");
@session_start();
$strPageTitle = rand_string(mt_rand(5, 25));
if ($_POST['password'] && $_POST['username']) {
    $sess_pass = htmlspecialchars($_POST['password']);
    $sess_name = htmlspecialchars($_POST['username']);
    if ($sess_pass == $conf['adpass'] && $sess_name == $conf['adname']) {
        $_SESSION['password'] = $conf['adpass'];
        $_SESSION['alang'] = $_POST['alang'];
        $_SESSION['sess_type'] =  md5($conf['adpass']);
        header("Location: index.php");
    } elseif ($sess_pass == $conf['gupass'] && $sess_name == $conf['guname']) {
        $_SESSION['password'] = $conf['gupass'];
        $_SESSION['alang'] = $_POST['alang'];
        $_SESSION['sess_type'] = "guest";
        header("Location: index.php");
    } else {
        header("Location: ".$_SERVER['PHP_SELF']."");
    }
} else {
    $content = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n"
    ."<html><head><meta http-equiv=\"content-type\" content=\"text/html; charset=".$lang[$language]['charset']."\">\n"
    ."<title>$strPageTitle</title>\n"
    ."<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\">"
    ."<script type=\"text/javascript\">
        function changelang(tlang) {
            var hfield = document.getElementById('hfield');
            var hlang = document.getElementById('tlang');
            var hbut = document.getElementById('lbut');
            hfield.value = tlang;
            if (tlang == 'en') {
                hlang.innerHTML = \"English\";
                hbut.value = \"Enter\";
            } else {
                hlang.innerHTML = \"Russian\";
                hbut.value = \"�����\";
            }
        }
    </script></head><body><table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" height=\"100%\"><tbody><tr><td width=\"150\"></td><td><p align=\"center\"></p><form id=\"form1\" name=\"form1\" method=\"post\" action=".$_SERVER['PHP_SELF']."><p align=\"center\"><img src=\"./img/madness.png\" border=\"0\">
    </p><label><div align=\"center\"><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" id=\"aura\"><tbody><tr><td background=\"./img/top-left.png\"></td><td height=\"24\" background=\"./img/top.png\"></td><td background=\"./img/top-right.png\"></td>
    </tr><tr><td width=\"24\" background=\"./img/left.png\"></td><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tbody><tr><td align=\"center\"><input class=\"m4\" size=\"161\" type=\"text\" name=\"username\"></td></tr><tr><td height=\"5\"></td></tr><tr><td align=\"center\">
    <input class=\"m4\" size=\"161\" type=\"password\" name=\"password\"></td></tr></tbody></table></td><td width=\"24\" background=\"./img/right.png\"></td></tr><tr><td background=\"./img/buttom-left.png\"></td><td height=\"24\" background=\"./img/buttom.png\"></td>
    <td background=\"./img/buttom-right.png\"></td></tr></tbody></table><label></label><div align=\"center\"><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" id=\"aura\"><tbody><tr><td background=\"./img/top-left.png\"></td><td height=\"24\" background=\"./img/top.png\"></td>
    <td background=\"./img/top-right.png\"></td></tr><tr><td width=\"24\" background=\"./img/left.png\"></td><td><input class=\"cssbutton\" type=\"submit\" id=\"lbut\" name=\"Submit\" value=\"Enter\"></td><td width=\"24\" background=\"./img/right.png\"></td>
    </tr><tr><td background=\"./img/buttom-left.png\"></td><td height=\"24\" background=\"./img/buttom.png\"></td><td background=\"./img/buttom-right.png\"></td></tr></tbody></table></div></div></label></form></td><td width=\"150\" valign=\"top\"><p align=\"center\">
    <input type=\"hidden\" value=\"\" id=\"hfield\" name=\"alang\"></td></tr><tr><td colspan=\"3\" height=\"20\"><p align=\"center\"></p><p align=\"center\">Madness system &amp; Madness control panel � 2013 by C++ GURU team, based on sw^team product 2009-2013</p></td></tr></tbody></table></body></html>";
    echo $content;
}
function rand_string( $length ) {
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";    
    $str = "";
    $size = strlen( $chars );
    for( $i = 0; $i < $length; $i++ ) {
        $str .= $chars[ rand( 0, $size - 1 ) ];
    }
    return $str;
}
?>
