<?php
if (!defined("FILE")) die ("Illegal File Access");
error_reporting(0);
$conf 		 = array();
$conf['dbhost']  = "localhost";
$conf['dbname']  = "akro71_haxor";
$conf['dbuser']  = "akro71_hacker";
$conf['dbpass']  = "haxorbaba@@786";


$conf['adname']  = "admin";
$conf['adpass']  = "admin";
$conf['guname']  = "mad";
$conf['gupass']  = "madness";

$conf['time_out']= "5";
$conf['pages'] 	 = "80";
$conf['version'] = "Darkness Panel Mod For Madness by NoNh";
$conf['lang'] 	 = "en";
$conf['time'] 	 = "25";
$conf['time_on'] = "1";
$conf['auth'] 	 = "0";
$conf['pwdpath'] ="./pwd/";

$conf['command'] = "d3Rm";
$conf['timecmd'] = "0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0||0|0|0";
?>